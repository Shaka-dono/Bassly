package com.bassly.app

import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(16), dp(4))
        val back = TextView(this)
        back.text = "‹"
        back.textSize = 28f
        back.gravity = Gravity.CENTER
        back.setTextColor(Ui.text(this))
        back.setBackgroundResource(R.drawable.bg_circle_btn)
        back.setOnClickListener { finish() }
        head.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = Ui.label(this, getString(R.string.set_title), 30f, Ui.text(this), true)
        t.setPadding(dp(14), 0, 0, 0)
        head.addView(t)
        root.addView(head)

        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, 0, 0, dp(32))
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun newCard(title: String): LinearLayout {
        val t = Ui.label(this, title.uppercase(), 12.5f, Ui.secondary(this), true)
        t.letterSpacing = 0.04f
        t.setPadding(dp(32), dp(24), dp(16), dp(8))
        list.addView(t)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.clipToOutline = true
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(16), 0, dp(16), 0)
        list.addView(card, lp)
        return card
    }

    private fun addRow(
        card: LinearLayout, title: String, summary: String?, trailing: View?, onClick: (() -> Unit)?
    ) {
        if (card.childCount > 0) {
            val div = View(this)
            div.setBackgroundColor(Ui.outline(this))
            val dl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
            dl.marginStart = dp(16)
            card.addView(div, dl)
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(14), dp(16), dp(14))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.label(this, title, 17f, Ui.text(this)))
        if (summary != null) {
            val st = Ui.label(this, summary, 13f, Ui.secondary(this))
            st.setPadding(0, dp(2), 0, 0)
            col.addView(st)
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) row.addView(trailing)
        if (onClick != null) {
            val tv = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            row.setBackgroundResource(tv.resourceId)
            row.setOnClickListener { Ui.tap(it); onClick() }
        }
        card.addView(row)
    }

    private fun valueText(s: String) = Ui.label(this, s, 15f, Ui.secondary(this))

    private fun choiceRow(
        card: LinearLayout, title: String, entries: List<String>, values: List<String>,
        current: String, onPick: (String) -> Unit
    ) {
        val idx = values.indexOf(current).coerceAtLeast(0)
        addRow(card, title, null, valueText(entries[idx] + "  ›")) {
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setSingleChoiceItems(entries.toTypedArray(), idx) { d, w ->
                    d.dismiss()
                    onPick(values[w])
                    render()
                }
                .show()
        }
    }

    private fun switchRow(
        card: LinearLayout, title: String, summary: String?, checked: Boolean, onChange: (Boolean) -> Unit
    ) {
        val sw = MaterialSwitch(this)
        sw.isChecked = checked
        sw.setOnClickListener { Ui.tap(it); onChange(sw.isChecked) }
        addRow(card, title, summary, sw, null)
    }

    private fun putBool(key: String, v: Boolean) = Prefs.sp(this).edit().putBoolean(key, v).apply()
    private fun putStr(key: String, v: String) = Prefs.sp(this).edit().putString(key, v).apply()

    private fun render() {
        list.removeAllViews()
        val sp = Prefs.sp(this)

        val look = newCard(getString(R.string.set_sec_look))
        val accentNames = resources.getStringArray(R.array.accent_names).toList()
        choiceRow(look, getString(R.string.set_accent), accentNames, Appearance.accentIds, Prefs.accent(this)) {
            putStr("accent", it)
            recreate()
        }
        val curLang = AppCompatDelegate.getApplicationLocales().let { if (it.isEmpty()) "" else it[0]?.language ?: "" }
        choiceRow(
            look, getString(R.string.set_language),
            listOf(getString(R.string.lang_system), getString(R.string.lang_en), getString(R.string.lang_it)),
            listOf("", "en", "it"), curLang
        ) {
            AppCompatDelegate.setApplicationLocales(
                if (it.isEmpty()) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(it)
            )
        }

        val audio = newCard(getString(R.string.set_sec_audio))
        val a4s = listOf("432", "435", "440", "442", "444")
        choiceRow(audio, getString(R.string.set_a4), a4s.map { "$it Hz" }, a4s, (Prefs.a4(this)).toInt().toString()) {
            putStr("a4", it)
            Engine.core.tuning = it.toDouble()
        }
        switchRow(audio, getString(R.string.set_keep), getString(R.string.set_keep_sub), Prefs.keepScreen(this)) {
            putBool("keep_screen", it)
        }

        val midi = newCard(getString(R.string.set_sec_midi))
        val names = MidiIn.names
        addRow(
            midi, getString(R.string.set_midi_devices),
            if (names.isEmpty()) getString(if (MidiIn.supported) R.string.set_midi_none else R.string.set_midi_unsupported) else null,
            if (names.isEmpty()) null else valueText(names.joinToString("\n")), null
        )
        addRow(midi, getString(R.string.set_midi_help), getString(R.string.set_midi_help_sub), null, null)

        val an = newCard(getString(R.string.set_sec_analyzer))
        val floors = listOf("-60", "-80", "-90", "-100")
        choiceRow(an, getString(R.string.set_floor), floors.map { "$it dB" }, floors, Prefs.floorDb(this).toInt().toString()) {
            putStr("floor_db", it)
        }

        val about = newCard(getString(R.string.set_sec_about))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        addRow(about, getString(R.string.set_version), null, valueText(ver), null)
    }
}
