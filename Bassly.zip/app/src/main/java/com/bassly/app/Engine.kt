package com.bassly.app

import android.content.ContentValues
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.provider.MediaStore
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max

/** Collega il sintetizzatore all'altoparlante e tiene lo stato condiviso tra schermate, MIDI e servizio. */
object Engine {
    private const val CHUNK = 256
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val lock = Object()
    private var thread: Thread? = null
    private var loaded = false

    val core = BassCore()
    val outRing = Ring()
    val micRing = Ring()

    @Volatile private var uiActive = false

    val patch: BassPatch get() = core.patch
    val seq: Sequencer get() = core.seq

    fun load(c: Context) {
        if (loaded) return
        loaded = true
        Prefs.loadMisc(c)
        core.patch = Prefs.loadPatch(c)
        core.tuning = Prefs.a4(c)
        Prefs.loadSeq(c, core.seq)
    }

    fun saveAll(c: Context) {
        Prefs.savePatch(c, core.patch)
        Prefs.saveSeq(c, core.seq)
        Prefs.saveMisc(c)
    }

    /** `notify` = true per i cambi che non vengono dai cursori (preset, MIDI): le schermate si riallineano. */
    @Synchronized
    fun update(notify: Boolean = false, f: (BassPatch) -> BassPatch) {
        core.patch = f(core.patch)
        if (notify) notifyChanged()
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    fun notifyChanged() { main.post { for (l in listeners) l() } }

    fun setUiActive(b: Boolean) {
        uiActive = b
        if (b) wake()
    }

    fun wake() {
        ensureThread()
        synchronized(lock) { lock.notifyAll() }
    }

    fun noteOn(n: Int, vel: Float) {
        core.noteOn(n, vel)
        wake()
    }

    fun noteOff(n: Int) = core.noteOff(n)

    fun panic() = core.allOff()

    /** suona una nota breve per far sentire cosa si sta scrivendo nel sequencer */
    fun audition(n: Int) {
        noteOn(n, 0.8f)
        main.postDelayed({ core.noteOff(n) }, 220)
    }

    fun seqPlaying(): Boolean = core.seq.playing

    fun startSeq() {
        core.seq.start()
        wake()
        notifyChanged()
    }

    fun stopSeq() {
        core.seq.stop()
        notifyChanged()
    }

    private fun shouldRun(): Boolean = uiActive || core.seq.playing || !core.isSilent()

    @Synchronized
    private fun ensureThread() {
        if (thread?.isAlive == true) return
        val t = Thread({ audioLoop() }, "bassly-audio")
        t.isDaemon = true
        thread = t
        t.start()
    }

    private fun audioLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val l = FloatArray(CHUNK)
        val r = FloatArray(CHUNK)
        val inter = FloatArray(CHUNK * 2)
        while (true) {
            synchronized(lock) {
                while (!shouldRun()) {
                    try {
                        lock.wait(1000)
                    } catch (e: InterruptedException) {
                        return
                    }
                }
            }
            val track = try {
                val minBytes = AudioTrack.getMinBufferSize(44100, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(44100)
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(max(CHUNK * 8 * 2, minBytes))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build()
            } catch (e: Exception) {
                try { Thread.sleep(500) } catch (x: InterruptedException) { return }
                continue
            }
            track.play()
            while (shouldRun()) {
                core.render(l, r, CHUNK)
                outRing.write(l, CHUNK)
                Recorder.feed(l, CHUNK)
                for (i in 0 until CHUNK) {
                    inter[2 * i] = l[i]
                    inter[2 * i + 1] = r[i]
                }
                val w = track.write(inter, 0, inter.size, AudioTrack.WRITE_BLOCKING)
                if (w < 0) break
            }
            try { track.stop() } catch (e: Exception) { }
            track.release()
        }
    }
}

/** Registra l'uscita in un file WAV (mono, 16 bit) e lo salva in Musica/Bassly. */
object Recorder {
    private const val MAX_SECONDS = 600
    private val main = Handler(Looper.getMainLooper())
    private val queue = LinkedBlockingQueue<ShortArray>()
    private val END = ShortArray(0)

    @Volatile var recording = false
        private set
    @Volatile private var startedAt = 0L
    @Volatile private var frames = 0L
    var onSaved: ((String?) -> Unit)? = null

    fun elapsedMs(): Long = if (recording) SystemClock.elapsedRealtime() - startedAt else 0L

    fun start(c: Context): Boolean {
        if (recording) return true
        val ctx = c.applicationContext
        val tmp = File(ctx.cacheDir, "rec.wav")
        val raf = try {
            RandomAccessFile(tmp, "rw").also { it.setLength(0); it.write(ByteArray(44)) }
        } catch (e: Exception) {
            return false
        }
        queue.clear()
        frames = 0
        startedAt = SystemClock.elapsedRealtime()
        recording = true
        val t = Thread {
            var written = 0L
            try {
                val bb = java.nio.ByteBuffer.allocate(CH_BYTES).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                while (true) {
                    val s = queue.take()
                    if (s === END) break
                    bb.clear()
                    for (x in s) bb.putShort(x)
                    raf.write(bb.array(), 0, s.size * 2)
                    written += s.size * 2L
                }
                raf.seek(0)
                raf.write(header(written))
                raf.close()
                val name = "Bassly-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".wav"
                val ok = if (written > 0) saveToMusic(ctx, tmp, name) else false
                tmp.delete()
                main.post { onSaved?.invoke(if (ok) name else null) }
            } catch (e: Exception) {
                try { raf.close() } catch (x: Exception) { }
                main.post { onSaved?.invoke(null) }
            }
        }
        t.isDaemon = true
        t.start()
        return true
    }

    fun stop() {
        if (!recording) return
        recording = false
        queue.add(END)
    }

    fun feed(buf: FloatArray, n: Int) {
        if (!recording) return
        if (frames > MAX_SECONDS * 44100L) {
            stop()
            return
        }
        val s = ShortArray(n)
        for (i in 0 until n) {
            val v = (buf[i] * 32767f).toInt()
            s[i] = (if (v > 32767) 32767 else if (v < -32768) -32768 else v).toShort()
        }
        frames += n
        queue.add(s)
    }

    private const val CH_BYTES = 4096

    private fun header(dataLen: Long): ByteArray {
        val b = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt((36 + dataLen).toInt()); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(44100); b.putInt(44100 * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen.toInt())
        return b.array()
    }

    private fun saveToMusic(c: Context, src: File, name: String): Boolean {
        return try {
            val values = ContentValues()
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Bassly")
            values.put(MediaStore.Audio.Media.IS_PENDING, 1)
            val uri = c.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            c.contentResolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            c.contentResolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }
}

/** Microfono per l'analizzatore (attivo solo mentre la pagina Spettro lo richiede). */
object Mic {
    @Volatile private var running = false
    @Volatile private var token = 0

    fun isRunning() = running

    fun start(): Boolean {
        if (running) return true
        val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val rec = try {
            @Suppress("MissingPermission")
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, 44100,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, 8192)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        running = true
        val my = ++token
        val t = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val s = ShortArray(1024)
            val f = FloatArray(1024)
            try {
                rec.startRecording()
                while (running && token == my) {
                    val n = rec.read(s, 0, s.size)
                    if (n <= 0) continue
                    for (i in 0 until n) f[i] = s[i] / 32768f
                    Engine.micRing.write(f, n)
                }
            } catch (e: Exception) {
            } finally {
                try { rec.stop() } catch (e: Exception) { }
                rec.release()
                if (token == my) running = false
            }
        }
        t.isDaemon = true
        t.start()
        return true
    }

    fun stop() {
        running = false
    }
}
