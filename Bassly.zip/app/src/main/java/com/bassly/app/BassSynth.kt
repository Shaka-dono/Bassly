package com.bassly.app

import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

const val SR = 44100.0

/** Buffer circolare per scope e spettro. */
class Ring(val size: Int = 8192) {
    private val buf = FloatArray(size)
    @Volatile private var pos = 0

    fun write(src: FloatArray, n: Int) {
        var p = pos
        for (i in 0 until n) {
            buf[p] = src[i]
            p++
            if (p == size) p = 0
        }
        pos = p
    }

    /** copia gli ultimi `count` campioni (in ordine di tempo) */
    fun latest(dst: FloatArray, count: Int) {
        var p = pos - count
        if (p < 0) p += size
        for (i in 0 until count) {
            dst[i] = buf[p]
            p++
            if (p == size) p = 0
        }
    }

    fun clear() {
        java.util.Arrays.fill(buf, 0f)
    }
}

/** Tutti i parametri del suono. I valori sono quelli che l'utente vede. */
data class BassPatch(
    val osc1: Int = 3,            // 0 sin, 1 square, 2 tri, 3 saw
    val osc2: Int = 3,
    val osc2Level: Float = 0.5f,
    val osc2Semi: Int = 0,
    val detune: Double = 9.0,     // cent
    val sub: Float = 0.6f,
    val subWave: Int = 0,         // 0 sine, 1 square
    val noise: Float = 0f,
    val cutoff: Double = 500.0,
    val res: Float = 0.3f,
    val drive: Float = 0.2f,
    val envAmt: Float = 0.5f,
    val fDecay: Double = 0.25,
    val punch: Float = 0f,        // calo di intonazione all'attacco (0..1 → 0..12 semitoni)
    val attack: Double = 0.003,
    val decay: Double = 0.3,
    val sustain: Float = 0.8f,
    val release: Double = 0.15,
    val lfoTarget: Int = 0,       // 0 cutoff, 1 pitch, 2 volume
    val lfoShape: Int = 0,        // 0 sin, 1 tri, 2 square, 3 saw
    val lfoRate: Double = 4.0,
    val lfoSync: Boolean = false,
    val lfoDiv: Int = 2,
    val lfoDepth: Float = 0f,
    val mono: Boolean = true,
    val glide: Double = 0.04,
    val volume: Float = 0.7f
)

object Lfo {
    /** quanti battiti dura un ciclo: 1 battuta, 1/2, 1/4, 1/8, 1/16, 1/8 terzine */
    val beatsPerCycle = doubleArrayOf(4.0, 2.0, 1.0, 0.5, 0.25, 1.0 / 3.0)
    val divNames = listOf("1/1", "1/2", "1/4", "1/8", "1/16", "1/8T")
}

class Step(var on: Boolean = false, var note: Int = 33, var accent: Boolean = false, var slide: Boolean = false) {
    fun copyFrom(o: Step) { on = o.on; note = o.note; accent = o.accent; slide = o.slide }
}

/** Sequencer a 16 step con tempo preciso al campione. */
class Sequencer {
    companion object { const val MAX = 16 }

    val steps = Array(MAX) { Step() }
    @Volatile var playing = false
    @Volatile var bpm = 110.0
    @Volatile var swing = 0f
    @Volatile var gate = 0.6f
    @Volatile var length = 16
    @Volatile var transpose = 0
    @Volatile var pos = -1          // step corrente (per l'interfaccia)

    internal var stepLeft = 0.0
    internal var gateLeft = 0.0
    internal var gateActive = false
    internal var curNote = 0

    fun stepDuration(index: Int): Double {
        val base = SR * 60.0 / bpm / 4.0
        val s = swing.toDouble().coerceIn(0.0, 0.6)
        return if (index % 2 == 0) base * (1.0 + s) else base * (1.0 - s)
    }

    fun start() {
        pos = length - 1
        stepLeft = 0.0
        gateLeft = 0.0
        gateActive = false
        playing = true
    }

    fun stop() {
        playing = false
    }
}

class BassCore {
    @Volatile var patch = BassPatch()
    val seq = Sequencer()
    @Volatile var tuning = 440.0
    @Volatile var bend = 0f            // semitoni
    @Volatile var modWheel = 0f        // 0..1 aumenta la profondità dell'LFO
    @Volatile var currentFreq = 0.0
    val sounding = BooleanArray(128)

    private class Ev(val type: Int, val note: Int, val vel: Float)

    private val events = ConcurrentLinkedQueue<Ev>()

    private inner class Voice {
        var stage = 0                  // 0 libera, 1 attacco, 2 decadimento, 3 sostegno, 4 rilascio
        var note = 0
        var vel = 1f
        var age = 0L
        var env = 0f
        var fenv = 0f
        var penv = 0f
        var lf = 0.0                   // log2 della frequenza corrente
        var lfT = 0.0
        var ph1 = 0.0
        var ph2 = 0.0
        var phS = 0.0
        var dt1 = 0.0
        var dt2 = 0.0
        var dtS = 0.0
        var a1 = 0.0; var a2 = 0.0; var a3 = 0.0; var kk = 0.0
        var ic1a = 0.0; var ic2a = 0.0; var ic1b = 0.0; var ic2b = 0.0
        var held = false

        fun trigger(n: Int, v: Float, retrigger: Boolean) {
            val fresh = stage == 0
            note = n
            vel = v
            lfT = ln(tuning * 2.0.pow((n - 69) / 12.0)) / ln(2.0)
            if (fresh) {
                lf = lfT
                ph1 = 0.0; ph2 = 0.0; phS = 0.0
                ic1a = 0.0; ic2a = 0.0; ic1b = 0.0; ic2b = 0.0
                env = 0f
            }
            if (retrigger || fresh) {
                fenv = 1f
                penv = 1f
                stage = 1
            }
            if (patch.glide < 0.002) lf = lfT
            held = true
            age = ++counter
        }

        fun release() {
            held = false
            if (stage != 0) stage = 4
        }
    }

    private var counter = 0L
    private val voices = Array(6) { Voice() }

    // pila delle note tenute (modalità mono)
    private val stack = IntArray(64)
    private var stackN = 0
    private var sustain = false
    private val deferred = BooleanArray(128)

    // stato di controllo (ogni CR campioni)
    private val CR = 16
    private var ctl = 0
    private var lfoPh = 0.0
    private var lfoVal = 0f
    private var cutSm = 500.0
    private var rng = 22222u

    // valori derivati dal patch, ricalcolati a ogni passo di controllo
    private var gainOsc2 = 0f
    private var aInc = 0f
    private var dCoef = 0f
    private var rCoef = 0f
    private var fdCoef = 0f
    private var pdCoef = 0f
    private var glideCoef = 1.0
    private var driveGain = 1f
    private var driveComp = 1f
    private var lfoAmpGain = 1f

    fun noteOn(n: Int, vel: Float) { events.add(Ev(0, n, vel)) }
    fun noteOff(n: Int) { events.add(Ev(1, n, 0f)) }
    fun pedal(down: Boolean) { events.add(Ev(2, if (down) 1 else 0, 0f)) }
    fun allOff() { events.add(Ev(3, 0, 0f)) }

    fun isSilent(): Boolean {
        if (!events.isEmpty()) return false
        for (v in voices) if (v.stage != 0) return false
        return true
    }

    fun reset() {
        for (v in voices) { v.stage = 0; v.env = 0f; v.held = false }
        stackN = 0
        java.util.Arrays.fill(sounding, false)
        java.util.Arrays.fill(deferred, false)
        events.clear()
    }

    // ---------- gestione delle note (solo dal thread audio) ----------

    private fun removeFromStack(n: Int) {
        var j = 0
        for (i in 0 until stackN) if (stack[i] != n) stack[j++] = stack[i]
        stackN = j
    }

    private fun doNoteOn(n: Int, vel: Float, forceLegato: Boolean) {
        if (n !in 0..127) return
        sounding[n] = true
        deferred[n] = false
        if (patch.mono) {
            val legato = stackN > 0 || forceLegato
            removeFromStack(n)
            if (stackN < stack.size) stack[stackN++] = n
            val v = voices[0]
            val canGlide = v.stage in 1..3 && legato
            v.trigger(n, vel, !canGlide)
            for (i in 1 until voices.size) if (voices[i].stage != 0) voices[i].release()
        } else {
            // stessa nota già presente: riusa la voce
            var target: Voice? = null
            for (v in voices) if (v.note == n && v.stage in 1..3) { target = v; break }
            if (target == null) for (v in voices) if (v.stage == 0) { target = v; break }
            if (target == null) {
                var best: Voice? = null
                for (v in voices) if (v.stage == 4 && (best == null || v.age < best.age)) best = v
                if (best == null) for (v in voices) if (best == null || v.age < best.age) best = v
                target = best
            }
            target!!.trigger(n, vel, true)
            target.lf = target.lfT
        }
    }

    private fun doNoteOff(n: Int) {
        if (n !in 0..127) return
        if (sustain) { deferred[n] = true; return }
        sounding[n] = false
        if (patch.mono) {
            removeFromStack(n)
            val v = voices[0]
            if (stackN > 0) {
                val top = stack[stackN - 1]
                if (v.note != top) {
                    v.lfT = ln(tuning * 2.0.pow((top - 69) / 12.0)) / ln(2.0)
                    v.note = top
                    if (patch.glide < 0.002) v.lf = v.lfT
                }
            } else {
                v.release()
            }
        } else {
            for (v in voices) if (v.note == n && v.held) v.release()
        }
    }

    private fun handle(e: Ev) {
        when (e.type) {
            0 -> doNoteOn(e.note, e.vel, false)
            1 -> doNoteOff(e.note)
            2 -> {
                val down = e.note == 1
                sustain = down
                if (!down) for (n in 0 until 128) if (deferred[n]) { deferred[n] = false; doNoteOff(n) }
            }
            3 -> {
                sustain = false
                java.util.Arrays.fill(deferred, false)
                java.util.Arrays.fill(sounding, false)
                stackN = 0
                for (v in voices) v.release()
            }
        }
    }

    // ---------- sequencer ----------

    private fun seqFire() {
        val s = seq
        if (s.gateActive && s.gateLeft <= 0.0) {
            val nxt = s.steps[(s.pos + 1) % s.length.coerceAtLeast(1)]
            if (!(nxt.on && nxt.slide)) {
                doNoteOff(s.curNote)
                s.gateActive = false
            }
            s.gateLeft = Double.MAX_VALUE
        }
        if (s.stepLeft <= 0.0) {
            val len = s.length.coerceIn(1, Sequencer.MAX)
            s.pos = (s.pos + 1) % len
            val st = s.steps[s.pos]
            s.stepLeft += s.stepDuration(s.pos)
            if (st.on) {
                val note = (st.note + s.transpose).coerceIn(0, 127)
                val legato = s.gateActive
                val prev = s.curNote
                doNoteOn(note, if (st.accent) 1f else 0.72f, legato)
                if (legato && prev != note) doNoteOff(prev)
                s.curNote = note
                s.gateActive = true
                s.gateLeft = s.stepDuration(s.pos) * s.gate.toDouble().coerceIn(0.05, 1.0)
            }
        }
    }

    // ---------- rendering ----------

    fun render(l: FloatArray, r: FloatArray, n: Int) {
        while (true) {
            val e = events.poll() ?: break
            handle(e)
        }
        var pos = 0
        while (pos < n) {
            var seg = n - pos
            val s = seq
            if (s.playing) {
                var guard = 0
                while (guard++ < 8 && (s.stepLeft <= 0.0 || (s.gateActive && s.gateLeft <= 0.0))) seqFire()
                val until = min(s.stepLeft, if (s.gateActive) s.gateLeft else Double.MAX_VALUE)
                val c = kotlin.math.ceil(until).toInt().coerceAtLeast(1)
                if (c < seg) seg = c
            } else if (s.gateActive) {
                doNoteOff(s.curNote)
                s.gateActive = false
                s.pos = -1
            }
            renderSeg(l, pos, seg)
            if (s.playing) {
                s.stepLeft -= seg
                if (s.gateActive) s.gateLeft -= seg
            }
            pos += seg
        }
        for (i in 0 until n) r[i] = l[i]
    }

    private fun updateControl() {
        val p = patch
        cutSm += (p.cutoff - cutSm) * 0.2
        // LFO
        val rate = if (p.lfoSync) (seq.bpm / 60.0) / Lfo.beatsPerCycle[p.lfoDiv.coerceIn(0, 5)] else p.lfoRate
        lfoPh += rate * CR / SR
        if (lfoPh >= 1.0) lfoPh -= 1.0
        lfoVal = when (p.lfoShape) {
            0 -> sin(2.0 * PI * lfoPh).toFloat()
            1 -> (4.0 * abs(lfoPh - 0.5) - 1.0).toFloat()
            2 -> (if (lfoPh < 0.5) 1f else -1f)
            else -> (1.0 - 2.0 * lfoPh).toFloat()
        }
        val depth = (p.lfoDepth + modWheel * 0.5f).coerceIn(0f, 1f)
        lfoVal *= depth
        lfoAmpGain = if (p.lfoTarget == 2) 1f - 0.5f * depth * (1f + lfoVal / max(depth, 0.0001f)) else 1f
        gainOsc2 = p.osc2Level
        aInc = (1.0 / (max(p.attack, 0.002) * SR)).toFloat()
        dCoef = exp(-6.9 / (max(p.decay, 0.005) * SR)).toFloat()
        rCoef = exp(-6.9 / (max(p.release, 0.004) * SR)).toFloat()
        fdCoef = exp(-6.9 * CR / (max(p.fDecay, 0.01) * SR)).toFloat()
        pdCoef = exp(-CR / (0.08 * SR)).toFloat()
        glideCoef = if (p.glide < 0.002) 1.0 else 1.0 - exp(-CR / (p.glide * SR))
        driveGain = 1f + p.drive * 9f
        driveComp = 1f / (1f + p.drive * 1.6f)
        val q = 0.6 + p.res.toDouble() * p.res * 5.0
        val k = 1.0 / q
        val maxHz = min(16000.0, SR * 0.42)
        var any = false
        for (v in voices) {
            if (v.stage == 0) continue
            any = true
            v.lf += (v.lfT - v.lf) * glideCoef
            v.fenv *= fdCoef
            v.penv *= pdCoef
            // intonazione
            var semis = bend.toDouble() + v.penv * p.punch * 12.0
            if (p.lfoTarget == 1) semis += lfoVal * 2.0
            val f = 2.0.pow(v.lf + semis / 12.0)
            val f2 = f * 2.0.pow((p.osc2Semi * 100.0 + p.detune) / 1200.0)
            v.dt1 = f / SR
            v.dt2 = f2 / SR
            v.dtS = f / SR * 0.5
            if (v === voices[0] || !p.mono) currentFreq = f
            // filtro
            var oct = p.envAmt * 5.0 * v.fenv * (0.5 + 0.5 * v.vel)
            if (p.lfoTarget == 0) oct += lfoVal * 3.5
            val fc = (cutSm * 2.0.pow(oct)).coerceIn(25.0, maxHz)
            val g = tan(PI * fc / SR)
            v.kk = k
            v.a1 = 1.0 / (1.0 + g * (g + k))
            v.a2 = g * v.a1
            v.a3 = g * v.a2
            if (abs(v.ic1a) < 1e-15) v.ic1a = 0.0
            if (abs(v.ic2a) < 1e-15) v.ic2a = 0.0
            if (abs(v.ic1b) < 1e-15) v.ic1b = 0.0
            if (abs(v.ic2b) < 1e-15) v.ic2b = 0.0
        }
        if (!any) currentFreq = 0.0
    }

    private fun blep(t: Double, dt: Double): Double {
        if (t < dt) {
            val x = t / dt
            return x + x - x * x - 1.0
        }
        if (t > 1.0 - dt) {
            val x = (t - 1.0) / dt
            return x * x + x + x + 1.0
        }
        return 0.0
    }

    private fun osc(w: Int, ph: Double, dt: Double): Double = when (w) {
        0 -> sin(2.0 * PI * ph)
        1 -> {
            var v = if (ph < 0.5) 1.0 else -1.0
            v += blep(ph, dt)
            v -= blep((ph + 0.5) % 1.0, dt)
            v
        }
        2 -> 4.0 * abs(ph - 0.5) - 1.0
        else -> 2.0 * ph - 1.0 - blep(ph, dt)
    }

    private fun sat(x: Float): Float {
        val a = if (x > 3f) 3f else if (x < -3f) -3f else x
        return a * (27f + a * a) / (27f + 9f * a * a)
    }

    private fun renderSeg(out: FloatArray, off: Int, cnt: Int) {
        val p = patch
        val polyGain = if (p.mono) 1f else 0.6f
        val master = p.volume * 1.3f * polyGain
        for (i in 0 until cnt) {
            if (ctl == 0) updateControl()
            ctl = (ctl + 1) and 15
            var sum = 0f
            for (v in voices) {
                if (v.stage == 0) continue
                when (v.stage) {
                    1 -> { v.env += aInc; if (v.env >= 1f) { v.env = 1f; v.stage = 2 } }
                    2 -> {
                        val s = p.sustain
                        v.env = s + (v.env - s) * dCoef
                        if (v.env - s < 0.0005f) { v.env = s; v.stage = 3 }
                    }
                    3 -> v.env = p.sustain
                    else -> {
                        v.env *= rCoef
                        if (v.env < 0.0003f) { v.env = 0f; v.stage = 0; continue }
                    }
                }
                val s1 = osc(p.osc1, v.ph1, v.dt1)
                var m = s1 * 0.45
                if (gainOsc2 > 0.001f) m += osc(p.osc2, v.ph2, v.dt2) * gainOsc2 * 0.45
                if (p.noise > 0.001f) {
                    rng = rng xor (rng shl 13); rng = rng xor (rng shr 17); rng = rng xor (rng shl 5)
                    m += ((rng.toInt() / 2147483648.0)) * p.noise * 0.3
                }
                v.ph1 += v.dt1; if (v.ph1 >= 1.0) v.ph1 -= 1.0
                v.ph2 += v.dt2; if (v.ph2 >= 1.0) v.ph2 -= 1.0
                v.phS += v.dtS; if (v.phS >= 1.0) v.phS -= 1.0
                var x = m.toFloat()
                if (p.drive > 0.01f) x = sat(x * driveGain) * driveComp * 1.4f
                // filtro passa-basso a 24 dB/ottava (due SVF in serie)
                val xd = x.toDouble()
                var v3 = xd - v.ic2a
                var v1 = v.a1 * v.ic1a + v.a2 * v3
                var v2 = v.ic2a + v.a2 * v.ic1a + v.a3 * v3
                v.ic1a = 2.0 * v1 - v.ic1a
                v.ic2a = 2.0 * v2 - v.ic2a
                v3 = v2 - v.ic2b
                v1 = v.a1 * v.ic1b + v.a2 * v3
                v2 = v.ic2b + v.a2 * v.ic1b + v.a3 * v3
                v.ic1b = 2.0 * v1 - v.ic1b
                v.ic2b = 2.0 * v2 - v.ic2b
                var y = v2.toFloat()
                // il sub passa dopo il filtro, così il basso resta pieno
                if (p.sub > 0.001f) {
                    val sb = if (p.subWave == 0) sin(2.0 * PI * v.phS) else (if (v.phS < 0.5) 0.8 else -0.8)
                    y += (sb * p.sub * 0.6).toFloat()
                }
                sum += y * v.env * (0.35f + 0.65f * v.vel) * lfoAmpGain
            }
            out[off + i] = sat(sum * master)
        }
    }
}
