package com.bassly.app

import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Pagina "Pad": 16 pad colorati che suonano la scala scelta. */
class PadsPage(private val act: MainActivity) : LinearLayout(act) {

    private val ctx = act
    private val pads = PadsView(ctx)
    private val tvKey: TextView
    private val tvScale: TextView
    private val tvOct: TextView
    private val tvLatch: TextView

    private fun dp(v: Int) = Ui.dp(ctx, v)

    init {
        orientation = VERTICAL
        setPadding(dp(16), 0, dp(16), dp(12))

        val r1 = LinearLayout(ctx)
        r1.gravity = Gravity.CENTER_VERTICAL
        tvKey = chip { pickKey() }
        tvScale = chip { pickScale() }
        r1.addView(tvKey)
        r1.addView(tvScale)
        addView(r1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val r2 = LinearLayout(ctx)
        r2.gravity = Gravity.CENTER_VERTICAL
        r2.setPadding(0, dp(10), 0, 0)
        r2.addView(round("−") { shift(-12) }, LayoutParams(dp(44), dp(44)))
        tvOct = Ui.label(ctx, "", 15f, Ui.text(ctx), true)
        tvOct.gravity = Gravity.CENTER
        r2.addView(tvOct, LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT))
        r2.addView(round("+") { shift(12) }, LayoutParams(dp(44), dp(44)))
        val sp = android.view.View(ctx)
        r2.addView(sp, LayoutParams(0, 1, 1f))
        tvLatch = chip { toggleLatch() }
        r2.addView(tvLatch)
        addView(r2, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        addView(pads, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pads.noteFor = { i -> Scales.noteAt(Prefs.scale, Prefs.root, Prefs.padBase, i) }
        pads.onOn = { n, v -> Engine.noteOn(n, v) }
        pads.onOff = { n -> Engine.noteOff(n) }
    }

    private fun chip(onClick: () -> Unit): TextView {
        val t = Ui.label(ctx, "", 15f, Ui.text(ctx), true)
        t.setPadding(dp(16), dp(10), dp(16), dp(10))
        t.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 18)
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = dp(8)
        t.layoutParams = lp
        t.setOnClickListener { Ui.tap(it); onClick() }
        return t
    }

    private fun round(s: String, onClick: () -> Unit): TextView {
        val v = Ui.label(ctx, s, 22f, Ui.text(ctx), true)
        v.gravity = Gravity.CENTER
        v.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 14)
        v.setOnClickListener { Ui.tap(it); onClick() }
        return v
    }

    private fun shift(d: Int) {
        val nb = (Prefs.padBase + d).coerceIn(0, 48)
        if (nb == Prefs.padBase) return
        pads.releaseAll()
        Prefs.padBase = nb
        refresh()
    }

    private fun toggleLatch() {
        Prefs.padLatch = !Prefs.padLatch
        pads.latch = Prefs.padLatch
        refresh()
    }

    private fun pickKey() {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pad_key)
            .setSingleChoiceItems(Scales.keys.toTypedArray(), Prefs.root) { d, w ->
                pads.releaseAll()
                Prefs.root = w
                d.dismiss()
                refresh()
            }
            .show()
    }

    private fun pickScale() {
        val names = ctx.resources.getStringArray(R.array.scale_names)
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pad_scale)
            .setSingleChoiceItems(names, Prefs.scale) { d, w ->
                pads.releaseAll()
                Prefs.scale = w
                d.dismiss()
                refresh()
            }
            .show()
    }

    fun refresh() {
        val names = ctx.resources.getStringArray(R.array.scale_names)
        tvKey.text = ctx.getString(R.string.pad_key) + "  " + Scales.keys[Prefs.root]
        tvScale.text = names[Prefs.scale.coerceIn(0, names.size - 1)]
        tvOct.text = Scales.noteName(Prefs.padBase + Prefs.root).let { "▸ $it" }
        tvLatch.text = ctx.getString(R.string.pad_latch) + "  " + ctx.getString(if (Prefs.padLatch) R.string.on else R.string.off)
        tvLatch.setTextColor(if (Prefs.padLatch) Ui.onPrimary(ctx) else Ui.text(ctx))
        tvLatch.background = Ui.roundBg(ctx, if (Prefs.padLatch) Ui.primary(ctx) else Ui.surfaceVariant(ctx), 18)
        pads.latch = Prefs.padLatch
        pads.degreesPerScale = Scales.intervals[Prefs.scale.coerceIn(0, Scales.intervals.size - 1)].size
        pads.invalidate()
    }

    fun onHidden() = pads.releaseAll()
}
