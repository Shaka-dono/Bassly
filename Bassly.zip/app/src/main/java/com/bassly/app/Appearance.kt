package com.bassly.app

import android.app.Activity

object Appearance {
    val accentIds = listOf("orange", "blue", "teal", "indigo", "purple", "pink", "green")

    fun apply(a: Activity) {
        a.setTheme(
            when (Prefs.accent(a)) {
                "indigo" -> R.style.Theme_Bassly_Indigo
                "purple" -> R.style.Theme_Bassly_Purple
                "pink" -> R.style.Theme_Bassly_Pink
                "orange" -> R.style.Theme_Bassly_Orange
                "green" -> R.style.Theme_Bassly_Green
                "blue" -> R.style.Theme_Bassly_Blue
                else -> R.style.Theme_Bassly_Orange
            }
        )
    }
}
