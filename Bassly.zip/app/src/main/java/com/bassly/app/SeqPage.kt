package com.bassly.app

import android.view.Gravity
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.roundToInt

/** Pagina "Loop": sequencer a 16 step per scrivere giri di basso. */
class SeqPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    private val seq = Engine.seq
    private val root = LinearLayout(ctx)
    private val grid = SeqGridView(ctx)
    private val btnPlay: TextView
    private val tvKey: TextView
    private val tvScale: TextView
    private val tvLow: TextView
    private val rows = ArrayList<ParamRow>()
    private var lastPlaying = false

    private fun dp(v: Int) = Ui.dp(ctx, v)

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), 0, dp(16), dp(28))
        addView(root)

        btnPlay = Ui.label(ctx, "", 17f, Ui.onPrimary(ctx), true)
        btnPlay.gravity = Gravity.CENTER
        btnPlay.setPadding(dp(16), dp(15), dp(16), dp(15))
        btnPlay.setOnClickListener { Ui.tap(it); act.toggleSeq() }
        root.addView(btnPlay, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(W.title(ctx, ctx.getString(R.string.seq_pattern)))
        val gc = W.card(ctx)
        gc.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)))
        root.addView(gc)
        grid.low = Prefs.seqLow
        grid.onEdited = { }

        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val chips = LinearLayout(ctx)
        chips.setPadding(0, dp(12), 0, 0)
        tvKey = W.chip(ctx, "") { pickKey() }
        tvScale = W.chip(ctx, "") { pickScale() }
        tvLow = W.chip(ctx, "") { }
        chips.addView(tvKey)
        chips.addView(tvScale)
        chips.addView(W.chip(ctx, "▼ 8va") { moveLow(-12) })
        chips.addView(W.chip(ctx, "▲ 8va") { moveLow(12) })
        chips.addView(W.chip(ctx, ctx.getString(R.string.seq_random)) { randomize() })
        chips.addView(W.chip(ctx, ctx.getString(R.string.seq_clear)) { clear() })
        hs.addView(chips)
        root.addView(hs)
        root.addView(Ui.label(ctx, ctx.getString(R.string.seq_hint), 12.5f, Ui.secondary(ctx)).also { it.setPadding(dp(4), dp(10), dp(4), 0) })

        root.addView(W.title(ctx, ctx.getString(R.string.seq_settings)))
        val card = W.card(ctx)
        root.addView(card)
        addRow(card, ctx.getString(R.string.seq_tempo), 40.0, 220.0, { "%d BPM".format(it.roundToInt()) }, { seq.bpm }) { seq.bpm = it.roundToInt().toDouble() }
        addRow(card, ctx.getString(R.string.seq_swing), 0.0, 0.6, { "${(it / 0.6 * 100).roundToInt()}%" }, { seq.swing.toDouble() }) { seq.swing = it.toFloat() }
        addRow(card, ctx.getString(R.string.seq_gate), 0.1, 1.0, { "${(it * 100).roundToInt()}%" }, { seq.gate.toDouble() }) { seq.gate = it.toFloat() }
        addRow(card, ctx.getString(R.string.seq_length), 2.0, 16.0, { "%d".format(it.roundToInt()) }, { seq.length.toDouble() }) { seq.length = it.roundToInt() }
        addRow(card, ctx.getString(R.string.seq_transpose), -12.0, 12.0, { "%+d".format(it.roundToInt()) }, { seq.transpose.toDouble() }) { seq.transpose = it.roundToInt() }
    }

    private fun addRow(
        card: LinearLayout, title: String, min: Double, max: Double, show: (Double) -> String,
        get: () -> Double, set: (Double) -> Unit
    ) {
        if (card.childCount > 0) card.addView(W.divider(ctx))
        val r = ParamRow(ctx, title, min, max, false, show, get, set = { v ->
            set(v)
            grid.invalidate()
        })
        card.addView(r)
        rows.add(r)
    }

    private fun moveLow(d: Int) {
        val nl = (grid.low + d).coerceIn(12, 60)
        grid.low = nl
        Prefs.seqLow = nl
        refresh()
    }

    private fun randomize() {
        val low = Scales.randomize(seq, Prefs.scale, Prefs.root, grid.low)
        grid.low = low
        Prefs.seqLow = low
        refresh()
    }

    private fun clear() {
        for (s in seq.steps) { s.on = false; s.accent = false; s.slide = false }
        grid.invalidate()
    }

    private fun pickKey() {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pad_key)
            .setSingleChoiceItems(Scales.keys.toTypedArray(), Prefs.root) { d, w ->
                Prefs.root = w
                d.dismiss()
                refresh()
            }
            .show()
    }

    private fun pickScale() {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pad_scale)
            .setSingleChoiceItems(ctx.resources.getStringArray(R.array.scale_names), Prefs.scale) { d, w ->
                Prefs.scale = w
                d.dismiss()
                refresh()
            }
            .show()
    }

    fun refresh() {
        val names = ctx.resources.getStringArray(R.array.scale_names)
        tvKey.text = ctx.getString(R.string.pad_key) + "  " + Scales.keys[Prefs.root]
        tvScale.text = names[Prefs.scale.coerceIn(0, names.size - 1)]
        grid.low = Prefs.seqLow
        for (r in rows) r.sync()
        grid.invalidate()
        paintPlay()
    }

    private fun paintPlay() {
        val on = seq.playing
        lastPlaying = on
        btnPlay.text = ctx.getString(if (on) R.string.seq_stop else R.string.seq_play)
        btnPlay.background = Ui.roundBg(ctx, if (on) android.graphics.Color.rgb(255, 99, 88) else Ui.primary(ctx), 18)
    }

    fun frame() {
        if (seq.playing != lastPlaying) paintPlay()
        grid.invalidate()
    }
}
