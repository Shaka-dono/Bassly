package com.bassly.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var play: PlayPage
    private lateinit var sound: SoundPage
    private lateinit var pads: PadsPage
    private lateinit var seq: SeqPage
    private lateinit var spec: SpectrumPage
    private lateinit var pages: List<View>
    private lateinit var tvRec: TextView
    private lateinit var tvMidi: TextView
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private var appliedAccent = ""
    private var askedNotif = false
    private var micCallback: ((Boolean) -> Unit)? = null
    private var frameCount = 0

    private val listener: () -> Unit = { refreshCurrent() }

    private val ticker = object : Runnable {
        override fun run() {
            when (tab) {
                0 -> play.frame()
                3 -> seq.frame()
                4 -> spec.frame()
            }
            if (frameCount++ % 8 == 0) updateRecPill()
            handler.postDelayed(this, 33)
        }
    }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startSeq() }

    private val micPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (!ok) Toast.makeText(this, R.string.mic_denied, Toast.LENGTH_LONG).show()
            micCallback?.invoke(ok)
            micCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        Appearance.apply(this)
        super.onCreate(savedInstanceState)
        appliedAccent = Prefs.accent(this)
        Engine.load(this)
        MidiIn.start(this)
        buildUi()
        Recorder.onSaved = { name ->
            if (name != null) Toast.makeText(this, getString(R.string.rec_saved, name), Toast.LENGTH_LONG).show()
            else Toast.makeText(this, R.string.rec_failed, Toast.LENGTH_LONG).show()
            updateRecPill()
        }
        showTab(Prefs.lastTab(this).coerceIn(0, 4))
    }

    override fun onResume() {
        super.onResume()
        if (appliedAccent != Prefs.accent(this)) {
            recreate()
            return
        }
        Engine.core.tuning = Prefs.a4(this)
        Engine.addListener(listener)
        Engine.setUiActive(true)
        refreshCurrent()
        if (tab == 4) spec.onShown()
        handler.post(ticker)
        updateScreenFlag()
    }

    override fun onPause() {
        super.onPause()
        Engine.removeListener(listener)
        handler.removeCallbacks(ticker)
        play.onHidden()
        pads.onHidden()
        spec.onHidden()
        Recorder.stop()
        Engine.setUiActive(false)
        Engine.saveAll(this)
        Prefs.sp(this).edit().putInt("tab", tab).apply()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(20), dp(10), dp(16), dp(8))
        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        titleCol.addView(Ui.label(this, getString(R.string.app_name), 30f, Ui.text(this), true))
        tvMidi = Ui.label(this, "", 12f, Ui.primary(this), true)
        tvMidi.visibility = View.GONE
        titleCol.addView(tvMidi)
        header.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        tvRec = Ui.label(this, "", 14f, Ui.text(this), true)
        tvRec.gravity = Gravity.CENTER
        tvRec.setPadding(dp(14), dp(10), dp(14), dp(10))
        tvRec.setOnClickListener { Ui.tap(it); toggleRec() }
        val rl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rl.marginEnd = dp(10)
        header.addView(tvRec, rl)

        val gear = TextView(this)
        gear.text = "⚙️"
        gear.textSize = 20f
        gear.gravity = Gravity.CENTER
        gear.setBackgroundResource(R.drawable.bg_circle_btn)
        gear.setOnClickListener { Ui.tap(it); startActivity(Intent(this, SettingsActivity::class.java)) }
        header.addView(gear, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(header)

        val content = FrameLayout(this)
        play = PlayPage(this)
        sound = SoundPage(this)
        pads = PadsPage(this)
        seq = SeqPage(this)
        spec = SpectrumPage(this)
        pages = listOf(play, sound, pads, seq, spec)
        for (p in pages) content.addView(p)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.setBackgroundColor(Ui.surface(this))
        bar.setPadding(dp(4), dp(6), dp(4), dp(8))
        val items = listOf(
            "🎹" to R.string.tab_play, "🎚️" to R.string.tab_sound, "🥁" to R.string.tab_pads,
            "🔁" to R.string.tab_loop, "📊" to R.string.tab_spectrum
        )
        for ((i, entry) in items.withIndex()) {
            val t = TextView(this)
            t.text = entry.first + "\n" + getString(entry.second)
            t.textSize = 11.5f
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(6), 0, dp(6))
            t.setOnClickListener { v -> Ui.tap(v); showTab(i) }
            bar.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            tabViews.add(t)
        }
        root.addView(bar)
        setContentView(root)
    }

    fun showTab(i: Int) {
        if (tab != i) {
            play.onHidden()
            pads.onHidden()
            spec.onHidden()
        }
        tab = i
        for ((k, p) in pages.withIndex()) p.visibility = if (k == i) View.VISIBLE else View.GONE
        for ((k, t) in tabViews.withIndex()) {
            t.setTextColor(if (k == i) Ui.primary(this) else Ui.secondary(this))
            t.alpha = if (k == i) 1f else 0.85f
        }
        if (i == 4) spec.onShown()
        refreshCurrent()
        updateScreenFlag()
    }

    /** riallinea la pagina visibile ai valori correnti (preset, MIDI, sequencer) */
    private fun refreshCurrent() {
        when (tab) {
            0 -> play.refresh()
            1 -> sound.refresh()
            2 -> pads.refresh()
            3 -> seq.refresh()
        }
        val names = MidiIn.names
        if (names.isEmpty()) {
            tvMidi.visibility = View.GONE
        } else {
            tvMidi.visibility = View.VISIBLE
            tvMidi.text = "● MIDI · " + names.joinToString(", ")
        }
    }

    private fun updateScreenFlag() {
        if (Prefs.keepScreen(this)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun showPresets() {
        PresetSheet(this) { refreshCurrent() }.show()
    }

    // ---- registrazione ----

    private fun toggleRec() {
        if (Recorder.recording) {
            Recorder.stop()
        } else {
            Engine.wake()
            if (!Recorder.start(this)) Toast.makeText(this, R.string.rec_failed, Toast.LENGTH_LONG).show()
        }
        updateRecPill()
    }

    private fun updateRecPill() {
        if (Recorder.recording) {
            val s = Recorder.elapsedMs() / 1000
            tvRec.text = "■  %02d:%02d".format(s / 60, s % 60)
            tvRec.setTextColor(Color.WHITE)
            tvRec.background = Ui.roundBg(this, Color.rgb(255, 69, 58), 18)
        } else {
            tvRec.text = "●  " + getString(R.string.rec)
            tvRec.setTextColor(Color.rgb(255, 99, 88))
            tvRec.background = Ui.roundBg(this, Ui.surfaceVariant(this), 18)
        }
    }

    // ---- sequencer ----

    fun toggleSeq() {
        if (Engine.seqPlaying()) {
            Engine.stopSeq()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startSeq()
        }
    }

    private fun startSeq() {
        Engine.startSeq()
        ToneService.start(this)
    }

    // ---- microfono ----

    fun requestMic(cb: (Boolean) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            cb(true)
        } else {
            micCallback = cb
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun micOn() { if (spec.useMic && tab == 4) Mic.start() }
    fun micOff() { Mic.stop() }
}
