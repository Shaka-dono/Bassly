package com.bassly.app

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import kotlin.math.pow

/** Tastiere e controller MIDI collegati in USB (o Bluetooth): suonano il sintetizzatore. */
object MidiIn {
    private class Open(val device: MidiDevice, val port: MidiOutputPort, val name: String)

    private val main = Handler(Looper.getMainLooper())
    private val opened = HashMap<Int, Open>()
    private var manager: MidiManager? = null
    private var started = false

    @Volatile var names: List<String> = emptyList()
        private set

    val supported: Boolean get() = manager != null

    private val sink = object : MidiParser.Sink {
        override fun noteOn(ch: Int, note: Int, vel: Int) { Engine.noteOn(note, (vel / 127f).coerceIn(0.05f, 1f)) }
        override fun noteOff(ch: Int, note: Int) { Engine.noteOff(note) }
        override fun cc(ch: Int, num: Int, value: Int) {
            val x = value / 127f
            when (num) {
                1 -> Engine.core.modWheel = x
                64 -> Engine.core.pedal(value >= 64)
                71 -> Engine.update(true) { it.copy(res = x) }
                74 -> Engine.update(true) { it.copy(cutoff = 40.0 * (12000.0 / 40.0).pow(x.toDouble())) }
                73 -> Engine.update(true) { it.copy(attack = 0.002 * (2.0 / 0.002).pow(x.toDouble())) }
                72 -> Engine.update(true) { it.copy(release = 0.01 * (3.0 / 0.01).pow(x.toDouble())) }
                7 -> Engine.update(true) { it.copy(volume = x) }
                120, 123 -> Engine.panic()
            }
        }
        override fun bend(ch: Int, value: Int) { Engine.core.bend = (value - 8192) / 8192f * 2f }
        override fun program(ch: Int, num: Int) {
            val e = Factory.list.getOrNull(num) ?: return
            Prefs.presetName = e.name
            Engine.update(true) { e.patch }
        }
    }

    fun start(c: Context) {
        if (started) return
        val ctx = c.applicationContext
        if (!ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) return
        val m = ctx.getSystemService(Context.MIDI_SERVICE) as? MidiManager ?: return
        manager = m
        started = true
        m.registerDeviceCallback(object : MidiManager.DeviceCallback() {
            override fun onDeviceAdded(info: MidiDeviceInfo) { open(info) }
            override fun onDeviceRemoved(info: MidiDeviceInfo) { close(info.id) }
        }, main)
        for (info in m.devices) open(info)
    }

    private fun open(info: MidiDeviceInfo) {
        val m = manager ?: return
        if (info.outputPortCount == 0 || opened.containsKey(info.id)) return
        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI"
        m.openDevice(info, { dev ->
            if (dev != null) {
                val port = dev.openOutputPort(0)
                if (port == null) {
                    try { dev.close() } catch (e: Exception) { }
                } else {
                    val parser = MidiParser(sink)
                    port.connect(object : MidiReceiver() {
                        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
                            parser.feed(data, offset, count)
                        }
                    })
                    opened[info.id] = Open(dev, port, name)
                    refreshNames()
                }
            }
        }, main)
    }

    private fun close(id: Int) {
        val o = opened.remove(id) ?: return
        try { o.port.close() } catch (e: Exception) { }
        try { o.device.close() } catch (e: Exception) { }
        Engine.panic()
        refreshNames()
    }

    private fun refreshNames() {
        names = opened.values.map { it.name }
        Engine.notifyChanged()
    }
}
