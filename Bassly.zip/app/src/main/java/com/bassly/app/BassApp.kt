package com.bassly.app

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class BassApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        Engine.load(this)
    }
}
