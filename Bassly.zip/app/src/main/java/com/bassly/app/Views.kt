package com.bassly.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.SparseIntArray
import android.view.MotionEvent
import android.view.View
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** Manopola: si trascina in verticale. */
class KnobView(
    ctx: Context,
    private val label: String,
    private val min: Double,
    private val max: Double,
    private val log: Boolean,
    private val show: (Double) -> String,
    private val get: () -> Double,
    private val set: (Double) -> Unit
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val accent = Ui.primary(ctx)
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND; color = Ui.outline(ctx)
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d; strokeCap = Paint.Cap.ROUND; color = accent
    }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.surfaceVariant(ctx) }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f * d; strokeCap = Paint.Cap.ROUND; color = Ui.text(ctx)
    }
    private val tv = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accent; textSize = 12.5f * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val tl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.secondary(ctx); textSize = 10.5f * d; textAlign = Paint.Align.CENTER; letterSpacing = 0.05f
    }
    private val rect = RectF()
    private var pos = 0.0
    private var startY = 0f
    private var startPos = 0.0
    private var dragging = false

    private fun fromPos(x: Double): Double = if (log) min * (max / min).pow(x) else min + (max - min) * x
    private fun toPos(v: Double): Double {
        val c = v.coerceIn(min, max)
        return if (log) ln(c / min) / ln(max / min) else (c - min) / (max - min)
    }

    fun sync() {
        if (dragging) return
        pos = toPos(get())
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val textH = 30f * d
        val size = min(w - 8f * d, h - textH)
        val cx = w / 2f
        val cy = size / 2f + 3f * d
        val r = size / 2f - 5f * d
        rect.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rect, 135f, 270f, false, track)
        if (pos > 0.003) c.drawArc(rect, 135f, (270.0 * pos).toFloat(), false, arc)
        c.drawCircle(cx, cy, r - 8f * d, body)
        val ang = Math.toRadians(135.0 + 270.0 * pos)
        val r1 = r - 11f * d
        val r2 = r - 20f * d
        c.drawLine(
            cx + (kotlin.math.cos(ang) * r1).toFloat(), cy + (kotlin.math.sin(ang) * r1).toFloat(),
            cx + (kotlin.math.cos(ang) * r2).toFloat(), cy + (kotlin.math.sin(ang) * r2).toFloat(), tick
        )
        c.drawText(show(fromPos(pos)), cx, size + 13f * d, tv)
        c.drawText(label.uppercase(), cx, size + 26f * d, tl)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                startY = e.y
                startPos = pos
                Ui.tick(this)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return true
                pos = (startPos + (startY - e.y) / (170f * d)).coerceIn(0.0, 1.0)
                set(fromPos(pos))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Tastiera a due ottave, multi-tocco, con scivolamento da un tasto all'altro. */
class KeyboardView(ctx: Context) : View(ctx) {
    var base = 36
        set(v) { releaseAll(); field = v; invalidate() }
    var onOn: (Int, Float) -> Unit = { _, _ -> }
    var onOff: (Int) -> Unit = { }

    private val d = resources.displayMetrics.density
    private val accent = Ui.primary(ctx)
    private val whiteIdx = intArrayOf(0, 2, 4, 5, 7, 9, 11)
    private val blackSemis = intArrayOf(1, 3, 6, 8, 10)
    private val blackAfter = intArrayOf(0, 1, 3, 4, 5)       // dopo quale tasto bianco dell'ottava
    private val total = 25
    private val whites = 15
    private val ptr = SparseIntArray()
    private val pressed = IntArray(total)
    private val pw = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(236, 237, 243) }
    private val pb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 22, 32) }
    private val pa = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
    private val pl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(110, 114, 130); textSize = 10f * d; textAlign = Paint.Align.CENTER
    }
    private val sep = Paint().apply { color = Color.rgb(170, 174, 190); strokeWidth = 1f }
    private val r = RectF()

    private fun keyRect(i: Int, out: RectF) {
        val w = width.toFloat() / whites
        val oct = i / 12
        val s = i % 12
        val bi = blackSemis.indexOf(s)
        if (bi >= 0) {
            val wi = oct * 7 + blackAfter[bi]
            val bw = w * 0.62f
            val x = (wi + 1) * w - bw / 2f
            out.set(x, 0f, x + bw, height * 0.62f)
        } else {
            val wi = oct * 7 + whiteIdx.indexOf(s)
            out.set(wi * w, 0f, (wi + 1) * w, height.toFloat())
        }
    }

    private fun keyAt(x: Float, y: Float): Int {
        // prima i tasti neri, che stanno sopra
        for (i in 0 until total) {
            if (blackSemis.contains(i % 12)) {
                keyRect(i, r)
                if (x >= r.left && x < r.right && y < r.bottom) return i
            }
        }
        val w = width.toFloat() / whites
        val wi = (x / w).toInt().coerceIn(0, whites - 1)
        return (wi / 7) * 12 + whiteIdx[wi % 7]
    }

    override fun onDraw(c: Canvas) {
        val ext = Engine.core.sounding
        for (pass in 0..1) {
            for (i in 0 until total) {
                val black = blackSemis.contains(i % 12)
                if ((pass == 0) == black) continue
                keyRect(i, r)
                val n = base + i
                val on = pressed[i] > 0 || (n in 0..127 && ext[n])
                val paint = if (on) pa else if (black) pb else pw
                if (black) {
                    c.drawRoundRect(r, 4f * d, 4f * d, paint)
                } else {
                    val rr = RectF(r.left + 0.7f * d, r.top - 8f * d, r.right - 0.7f * d, r.bottom - 1.5f * d)
                    c.drawRoundRect(rr, 6f * d, 6f * d, paint)
                    if (i % 12 == 0) c.drawText(Scales.noteName(n), (r.left + r.right) / 2f, r.bottom - 10f * d, if (on) pb else pl)
                }
            }
        }
    }

    private fun press(id: Int, x: Float, y: Float) {
        val k = keyAt(x, y)
        ptr.put(id, k)
        down(k, y)
    }

    private fun down(k: Int, y: Float) {
        pressed[k]++
        val vel = (0.55f + 0.45f * (y / max(1f, height.toFloat()))).coerceIn(0.4f, 1f)
        if (pressed[k] == 1) onOn(base + k, vel)
        invalidate()
    }

    private fun up(k: Int) {
        if (pressed[k] > 0) {
            pressed[k]--
            if (pressed[k] == 0) onOff(base + k)
        }
        invalidate()
    }

    fun releaseAll() {
        for (i in 0 until ptr.size()) up(ptr.valueAt(i))
        ptr.clear()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val i = e.actionIndex
                press(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val cur = ptr.get(id, -1)
                    if (cur < 0) continue
                    val k = keyAt(e.getX(i), e.getY(i))
                    if (k != cur) {
                        down(k, e.getY(i))
                        ptr.put(id, k)
                        up(cur)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                val k = ptr.get(id, -1)
                if (k >= 0) { ptr.delete(id); up(k) }
            }
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }
}

/** Griglia 4×4 di pad colorati, ognuno suona un grado della scala. */
class PadsView(ctx: Context) : View(ctx) {
    var noteFor: (Int) -> Int = { it }
    var latch = false
        set(v) { if (field && !v) releaseAll(); field = v }
    var onOn: (Int, Float) -> Unit = { _, _ -> }
    var onOff: (Int) -> Unit = { }

    private val d = resources.displayMetrics.density
    private val ptr = SparseIntArray()
    private val on = BooleanArray(16)
    private val held = IntArray(16)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tx = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; textSize = 15f * d; typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val hues = floatArrayOf(18f, 42f, 130f, 175f, 205f, 250f, 290f, 335f)
    var degreesPerScale = 7

    private fun gridRect(): RectF {
        val gap = 10f * d
        val cell = min((width - gap * 3) / 4f, (height - gap * 3) / 4f)
        val gw = cell * 4 + gap * 3
        val x0 = (width - gw) / 2f
        val y0 = (height - gw) / 2f
        return RectF(x0, y0, x0 + gw, y0 + gw)
    }

    private fun padAt(x: Float, y: Float): Int {
        val g = gridRect()
        if (x < g.left || x > g.right || y < g.top || y > g.bottom) return -1
        val cell = g.width() / 4f
        val col = ((x - g.left) / cell).toInt().coerceIn(0, 3)
        val rowTop = ((y - g.top) / cell).toInt().coerceIn(0, 3)
        return (3 - rowTop) * 4 + col            // la riga in basso è la più grave
    }

    override fun onDraw(c: Canvas) {
        val g = gridRect()
        val gap = 10f * d
        val cell = (g.width() - gap * 3) / 4f
        for (i in 0 until 16) {
            val col = i % 4
            val row = 3 - i / 4
            val x = g.left + col * (cell + gap)
            val y = g.top + row * (cell + gap)
            rect.set(x, y, x + cell, y + cell)
            val deg = i % degreesPerScale.coerceAtLeast(1)
            val hue = hues[deg % hues.size]
            val lit = on[i] || held[i] > 0
            p.color = Color.HSVToColor(floatArrayOf(hue, if (lit) 0.35f else 0.62f, if (lit) 1f else 0.5f))
            c.drawRoundRect(rect, 16f * d, 16f * d, p)
            tx.color = if (lit) Color.rgb(20, 22, 32) else Color.argb(220, 255, 255, 255)
            val n = noteFor(i)
            val nm = Scales.noteName(n)
            c.drawText(nm, x + cell / 2f, y + cell / 2f + 5f * d, tx)
        }
    }

    private fun touchDown(k: Int) {
        if (latch) {
            on[k] = !on[k]
            if (on[k]) onOn(noteFor(k), 0.9f) else onOff(noteFor(k))
        } else {
            held[k]++
            if (held[k] == 1) onOn(noteFor(k), 0.9f)
        }
        invalidate()
    }

    private fun touchUp(k: Int) {
        if (!latch && held[k] > 0) {
            held[k]--
            if (held[k] == 0) onOff(noteFor(k))
        }
        invalidate()
    }

    fun releaseAll() {
        for (i in 0 until 16) {
            if (on[i]) { on[i] = false; onOff(noteFor(i)) }
            if (held[i] > 0) { held[i] = 0; onOff(noteFor(i)) }
        }
        ptr.clear()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val i = e.actionIndex
                val k = padAt(e.getX(i), e.getY(i))
                ptr.put(e.getPointerId(i), k)
                if (k >= 0) touchDown(k)
            }
            MotionEvent.ACTION_MOVE -> {
                if (latch) return true
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val cur = ptr.get(id, -1)
                    val k = padAt(e.getX(i), e.getY(i))
                    if (k != cur && k >= 0) {
                        touchDown(k)
                        ptr.put(id, k)
                        if (cur >= 0) touchUp(cur)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                val k = ptr.get(id, -1)
                if (k >= 0) touchUp(k)
                ptr.delete(id)
            }
            MotionEvent.ACTION_CANCEL -> {
                for (i in 0 until ptr.size()) { val k = ptr.valueAt(i); if (k >= 0) touchUp(k) }
                ptr.clear()
            }
        }
        return true
    }
}

/** Griglia del sequencer: 13 note × 16 step, più due righe per accento e slide. */
class SeqGridView(ctx: Context) : View(ctx) {
    var low = 24
        set(v) { field = v; invalidate() }
    var onEdited: () -> Unit = { }

    private val d = resources.displayMetrics.density
    private val seq = Engine.seq
    private val accent = Ui.primary(ctx)
    private val rows = 13
    private val labelW = 34f * d
    private val extraH = 26f * d
    private val gap = 1.5f * d
    private val pCell = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * d; textAlign = Paint.Align.RIGHT; color = Ui.secondary(ctx) }
    private val pTxtC = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * d; textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    // pittura trascinando
    private var paintKind = 0        // 0 nota, 1 accento, 2 slide
    private var paintSet = true
    private var paintNote = 0
    private var lastCol = -1

    private fun gridH(): Float = height - extraH * 2
    private fun colW(): Float = (width - labelW) / Sequencer.MAX
    private fun rowH(): Float = gridH() / rows

    override fun onDraw(c: Canvas) {
        val cw = colW()
        val rh = rowH()
        val len = seq.length
        val playPos = if (seq.playing) seq.pos else -1
        val root = Prefs.root
        val sc = Prefs.scale
        for (r in 0 until rows) {
            val note = low + 12 - r
            val y = r * rh
            val inScale = Scales.inScale(sc, root, note)
            val black = Scales.isBlack(note)
            val isRoot = Math.floorMod(note - root, 12) == 0
            if (isRoot || note % 12 == 0 || inScale) {
                c.drawText(Scales.noteName(note), labelW - 4f * d, y + rh / 2f + 3.5f * d, pTxt.also {
                    it.color = if (isRoot) accent else Ui.secondary(context)
                })
            }
            for (col in 0 until Sequencer.MAX) {
                val x = labelW + col * cw
                rect.set(x + gap, y + gap, x + cw - gap, y + rh - gap)
                val live = col < len
                var base = if (inScale) Color.rgb(44, 50, 70) else if (black) Color.rgb(25, 28, 40) else Color.rgb(31, 36, 51)
                if (isRoot && inScale) base = Color.rgb(58, 66, 92)
                pCell.color = if (live) base else Color.argb(90, Color.red(base), Color.green(base), Color.blue(base))
                c.drawRoundRect(rect, 3f * d, 3f * d, pCell)
            }
        }
        // note dei passi
        for (col in 0 until Sequencer.MAX) {
            val st = seq.steps[col]
            if (!st.on) continue
            val r = low + 12 - st.note
            val x = labelW + col * cw
            val live = col < len
            pCell.color = if (live) accent else Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent))
            if (r in 0 until rows) {
                rect.set(x + gap, r * rh + gap, x + cw - gap, r * rh + rh - gap)
                c.drawRoundRect(rect, 3f * d, 3f * d, pCell)
            } else {
                // nota fuori dalla finestra visibile: segnale in alto o in basso
                val y = if (r < 0) 2f * d else gridH() - 6f * d
                rect.set(x + gap, y, x + cw - gap, y + 4f * d)
                c.drawRoundRect(rect, 2f * d, 2f * d, pCell)
            }
        }
        // righe accento / slide
        for (kind in 0..1) {
            val y = gridH() + kind * extraH
            c.drawText(if (kind == 0) "ACC" else "SLD", labelW - 4f * d, y + extraH / 2f + 3.5f * d, pTxt.also { it.color = Ui.secondary(context) })
            for (col in 0 until Sequencer.MAX) {
                val st = seq.steps[col]
                val x = labelW + col * cw
                rect.set(x + gap, y + 3f * d, x + cw - gap, y + extraH - 3f * d)
                val flag = if (kind == 0) st.accent else st.slide
                val live = col < len
                pCell.color = if (flag) Color.rgb(255, 214, 90) else Color.rgb(31, 36, 51)
                if (!live) pCell.alpha = 90
                c.drawRoundRect(rect, 4f * d, 4f * d, pCell)
            }
        }
        // cursore di riproduzione
        if (playPos >= 0) {
            pCell.color = Color.argb(60, 255, 255, 255)
            val x = labelW + playPos * cw
            c.drawRect(x, 0f, x + cw, height.toFloat(), pCell)
        }
    }

    private fun apply(col: Int, y: Float, first: Boolean) {
        if (col !in 0 until Sequencer.MAX) return
        val st = seq.steps[col]
        when (paintKind) {
            0 -> {
                if (first) {
                    val r = (y / rowH()).toInt().coerceIn(0, rows - 1)
                    val note = low + 12 - r
                    paintNote = note
                    paintSet = !(st.on && st.note == note)
                }
                if (paintSet) {
                    val changed = !st.on || st.note != paintNote
                    st.on = true
                    st.note = paintNote
                    if (changed) Engine.audition(paintNote + seq.transpose)
                } else {
                    st.on = false
                }
            }
            1 -> { if (first) paintSet = !st.accent; st.accent = paintSet }
            else -> { if (first) paintSet = !st.slide; st.slide = paintSet }
        }
        onEdited()
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cw = colW()
        val col = ((e.x - labelW) / cw).toInt()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (e.x < labelW) return true
                paintKind = if (e.y < gridH()) 0 else if (e.y < gridH() + extraH) 1 else 2
                lastCol = col
                apply(col, e.y, true)
                Ui.tick(this)
            }
            MotionEvent.ACTION_MOVE -> {
                if (col != lastCol && col in 0 until Sequencer.MAX && e.x >= labelW) {
                    lastCol = col
                    apply(col, if (paintKind == 0) e.y.coerceIn(0f, gridH() - 1f) else e.y, false)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> lastCol = -1
        }
        return true
    }
}
