package com.bassly.app

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt

/** FFT radice 2 in-place. */
class Fft(val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(-2.0 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { sin(-2.0 * PI * it / n) }
    private val rev = IntArray(n)

    init {
        var bits = 0
        while ((1 shl bits) < n) bits++
        for (i in 0 until n) {
            var x = i
            var r = 0
            for (b in 0 until bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
    }

    fun transform(re: DoubleArray, im: DoubleArray) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var start = 0
            while (start < n) {
                var k = 0
                for (j in start until start + half) {
                    val wr = cosT[k]
                    val wi = sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                start += size
            }
            size *= 2
        }
    }
}

/** Spettro in bande logaritmiche 20 Hz .. 20 kHz, con ritorno morbido e picchi che restano un attimo. */
class Spectrum(private val sr: Double = SR, val n: Int = 4096, val bands: Int = 96) {
    private val fft = Fft(n)
    private val win = DoubleArray(n) { 0.5 - 0.5 * cos(2.0 * PI * it / n) }
    private val re = DoubleArray(n)
    private val im = DoubleArray(n)
    private val tmp = FloatArray(n)
    private val db = DoubleArray(n / 2)
    private val fLo = 20.0
    private val fHi = minOf(20000.0, sr / 2.0 * 0.98)

    val level = FloatArray(bands)
    val peak = FloatArray(bands)
    private val hold = IntArray(bands)

    @Volatile var peakFreq = 0.0
    @Volatile var peakDb = -120.0

    fun bandFreq(i: Float): Double = fLo * (fHi / fLo).pow(i.toDouble() / bands)

    /** Posizione 0..1 di una frequenza sull'asse logaritmico */
    fun posOf(f: Double): Float = (ln(f / fLo) / ln(fHi / fLo)).toFloat().coerceIn(0f, 1f)

    fun analyze(ring: Ring, floorDb: Double = -90.0) {
        ring.latest(tmp, n)
        for (i in 0 until n) {
            re[i] = tmp[i] * win[i]
            im[i] = 0.0
        }
        fft.transform(re, im)
        for (k in 0 until n / 2) {
            val a = 4.0 * sqrt(re[k] * re[k] + im[k] * im[k]) / n
            db[k] = 20.0 * log10(a + 1e-9)
        }
        val binHz = sr / n
        for (b in 0 until bands) {
            val f0 = bandFreq(b.toFloat())
            val f1 = bandFreq(b + 1f)
            val k0 = f0 / binHz
            val k1 = f1 / binHz
            var v: Double
            if (k1 - k0 < 1.0) {
                val kc = (k0 + k1) / 2.0
                val i = kc.toInt().coerceIn(0, n / 2 - 2)
                val fr = kc - i
                v = db[i] * (1 - fr) + db[i + 1] * fr
            } else {
                v = -200.0
                for (k in k0.toInt()..k1.toInt().coerceAtMost(n / 2 - 1)) if (db[k] > v) v = db[k]
            }
            val norm = ((v - floorDb) / -floorDb).toFloat().coerceIn(0f, 1f)
            level[b] = if (norm > level[b]) level[b] + (norm - level[b]) * 0.65f else maxOf(norm, level[b] - 0.03f)
            if (level[b] >= peak[b]) {
                peak[b] = level[b]
                hold[b] = 22
            } else if (hold[b] > 0) {
                hold[b]--
            } else {
                peak[b] = maxOf(level[b], peak[b] - 0.012f)
            }
        }
        // picco dominante con interpolazione parabolica
        val kMin = (fLo / binHz).toInt().coerceAtLeast(2)
        val kMax = (fHi / binHz).toInt().coerceAtMost(n / 2 - 2)
        var kb = kMin
        for (k in kMin..kMax) if (db[k] > db[kb]) kb = k
        val a = db[kb - 1]
        val bb = db[kb]
        val c = db[kb + 1]
        val den = a - 2.0 * bb + c
        val d = if (den != 0.0) (0.5 * (a - c) / den).coerceIn(-0.5, 0.5) else 0.0
        peakFreq = (kb + d) * binHz
        peakDb = bb - 0.25 * (a - c) * d
    }

    fun clear() {
        java.util.Arrays.fill(level, 0f)
        java.util.Arrays.fill(peak, 0f)
        peakDb = -120.0
        peakFreq = 0.0
    }
}

object Notes {
    private val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")

    /** "A4 +3¢" */
    fun describe(f: Double, a4: Double): String {
        if (f < 8.0) return "—"
        val semis = 12.0 * ln(f / a4) / ln(2.0) + 69.0
        val n = round(semis).toInt()
        val cents = ((semis - n) * 100.0).toInt()
        val name = names[((n % 12) + 12) % 12] + (n / 12 - 1)
        val c = if (cents >= 0) "+$cents" else "$cents"
        return "$name $c¢"
    }
}
