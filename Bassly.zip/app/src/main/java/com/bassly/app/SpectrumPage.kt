package com.bassly.app

import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Pagina "Spettro": analizzatore in tempo reale dell'uscita o del microfono. */
class SpectrumPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    val analyzer = Spectrum(SR, 8192, 96)
    private val specView = SpectrumView(ctx, analyzer)
    private val scope = ScopeView(ctx)
    private val tvPeak: TextView
    private val tvNote: TextView
    private val tvInfo: TextView
    private val btnFreeze: TextView
    private lateinit var srcSeg: Segmented
    var useMic = false
        private set
    private var frozen = false

    private fun dp(v: Int) = Ui.dp(ctx, v)

    init {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(4), dp(16), dp(24))
        addView(root)

        srcSeg = Segmented(ctx, listOf(ctx.getString(R.string.src_output), ctx.getString(R.string.src_mic)), 0) { i ->
            if (i == 1) act.requestMic { ok ->
                useMic = ok
                if (!ok) srcSeg.select(0)
                afterSourceChange()
            } else {
                useMic = false
                afterSourceChange()
            }
        }
        val sl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sl.bottomMargin = dp(12)
        root.addView(srcSeg, sl)

        val readout = W.card(ctx)
        val rl = LinearLayout(ctx)
        rl.gravity = Gravity.CENTER_VERTICAL
        rl.setPadding(dp(20), dp(16), dp(20), dp(16))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.label(ctx, ctx.getString(R.string.spec_peak).uppercase(), 12f, Ui.secondary(ctx), true))
        tvPeak = Ui.label(ctx, "—", 32f, Ui.text(ctx), true)
        tvNote = Ui.label(ctx, "", 16f, Ui.primary(ctx), true)
        tvInfo = Ui.label(ctx, "", 13.5f, Ui.secondary(ctx))
        col.addView(tvPeak)
        col.addView(tvNote)
        col.addView(tvInfo)
        rl.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btnFreeze = Ui.label(ctx, ctx.getString(R.string.spec_freeze), 14.5f, Ui.text(ctx), true)
        btnFreeze.setPadding(dp(18), dp(12), dp(18), dp(12))
        btnFreeze.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 16)
        btnFreeze.setOnClickListener {
            Ui.tap(it)
            frozen = !frozen
            btnFreeze.text = ctx.getString(if (frozen) R.string.spec_unfreeze else R.string.spec_freeze)
        }
        rl.addView(btnFreeze)
        readout.addView(rl)
        root.addView(readout)

        val specCard = W.card(ctx)
        specCard.addView(specView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(270)))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        root.addView(specCard, lp)

        root.addView(W.title(ctx, ctx.getString(R.string.spec_scope)))
        val scopeCard = W.card(ctx)
        scopeCard.addView(scope, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)))
        root.addView(scopeCard)
    }

    private fun afterSourceChange() {
        analyzer.clear()
        if (useMic) act.micOn() else act.micOff()
    }

    fun onShown() {
        if (useMic) act.micOn()
    }

    fun onHidden() {
        act.micOff()
    }

    /** ~30 volte al secondo mentre la pagina è visibile */
    fun frame() {
        specView.floorDb = Prefs.floorDb(ctx)
        specView.markerHz = if (!useMic) Engine.core.currentFreq else 0.0
        val ring = if (useMic) Engine.micRing else Engine.outRing
        if (!frozen) {
            val floor = Prefs.floorDb(ctx)
            analyzer.analyze(ring, floor)
            ring.latest(scope.data, 4096)
            if (analyzer.peakDb > floor + 12) {
                tvPeak.text = Fmt.hz(analyzer.peakFreq)
                tvNote.text = Notes.describe(analyzer.peakFreq, Prefs.a4(ctx))
                tvInfo.text = Fmt.db(analyzer.peakDb)
            } else {
                tvPeak.text = "—"
                tvNote.text = ""
                tvInfo.text = if (useMic) ctx.getString(R.string.spec_nosignal) else ctx.getString(R.string.spec_hint_out)
            }
        }
        specView.invalidate()
        scope.invalidate()
    }
}
