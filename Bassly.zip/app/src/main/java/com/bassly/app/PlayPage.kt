package com.bassly.app

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Pagina "Suona": scope e spettro, manopole principali e tastiera. */
class PlayPage(private val act: MainActivity) : LinearLayout(act) {

    private val ctx = act
    private val analyzer = Spectrum(SR, 8192, 80)
    private val scope = ScopeView(ctx, Color.rgb(79, 163, 255))
    private val specView = SpectrumView(ctx, analyzer, Color.rgb(255, 154, 60), false)
    private val knobs = ArrayList<KnobView>()
    private val keyboard = KeyboardView(ctx)
    private val tvPreset: TextView
    private val tvOct: TextView
    private lateinit var monoSeg: Segmented

    private fun dp(v: Int) = Ui.dp(ctx, v)
    private fun lp() = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun knob(
        label: String, min: Double, max: Double, log: Boolean, show: (Double) -> String,
        get: () -> Double, set: (Double) -> Unit
    ): KnobView {
        val k = KnobView(ctx, label, min, max, log, show, get, set)
        knobs.add(k)
        return k
    }

    private fun pct(v: Double) = "${(v * 100).roundToInt()}%"
    private fun p() = Engine.patch
    private fun up(f: (BassPatch) -> BassPatch) { Engine.update(false, f) }

    init {
        orientation = VERTICAL
        setPadding(dp(16), 0, dp(16), dp(8))

        // preset
        tvPreset = Ui.label(ctx, "", 16f, Ui.text(ctx), true)
        tvPreset.gravity = Gravity.CENTER_VERTICAL
        tvPreset.setPadding(dp(16), dp(10), dp(16), dp(10))
        tvPreset.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 16)
        tvPreset.maxLines = 1
        tvPreset.ellipsize = android.text.TextUtils.TruncateAt.END
        tvPreset.setOnClickListener { Ui.tap(it); act.showPresets() }
        addView(tvPreset, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.bottomMargin = dp(8) })

        // scope + spettro
        val viz = W.card(ctx)
        viz.orientation = HORIZONTAL
        viz.addView(scope, LayoutParams(0, dp(96), 1f))
        val dv = View(ctx)
        dv.setBackgroundColor(Ui.outline(ctx))
        viz.addView(dv, LayoutParams(1, ViewGroup.LayoutParams.MATCH_PARENT))
        viz.addView(specView, LayoutParams(0, dp(96), 1f))
        addView(viz, lp())

        // manopole
        val r1 = LinearLayout(ctx)
        r1.addView(knob(ctx.getString(R.string.k_cutoff), 40.0, 12000.0, true, { Fmt.hzShort(it) }, { p().cutoff }) { v -> up { it.copy(cutoff = v) } }, LayoutParams(0, dp(92), 1f))
        r1.addView(knob(ctx.getString(R.string.k_reso), 0.0, 1.0, false, { pct(it) }, { p().res.toDouble() }) { v -> up { it.copy(res = v.toFloat()) } }, LayoutParams(0, dp(92), 1f))
        r1.addView(knob(ctx.getString(R.string.k_drive), 0.0, 1.0, false, { pct(it) }, { p().drive.toDouble() }) { v -> up { it.copy(drive = v.toFloat()) } }, LayoutParams(0, dp(92), 1f))
        r1.addView(knob(ctx.getString(R.string.k_sub), 0.0, 1.0, false, { pct(it) }, { p().sub.toDouble() }) { v -> up { it.copy(sub = v.toFloat()) } }, LayoutParams(0, dp(92), 1f))
        addView(r1, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = dp(6) })
        val r2 = LinearLayout(ctx)
        r2.addView(knob(ctx.getString(R.string.k_env), 0.0, 1.0, false, { pct(it) }, { p().envAmt.toDouble() }) { v -> up { it.copy(envAmt = v.toFloat()) } }, LayoutParams(0, dp(92), 1f))
        r2.addView(knob(ctx.getString(R.string.k_decay), 0.03, 3.0, true, { Fmt.sec(it) }, { p().fDecay }) { v -> up { it.copy(fDecay = v) } }, LayoutParams(0, dp(92), 1f))
        r2.addView(knob(ctx.getString(R.string.k_glide), 0.0, 0.6, false, { Fmt.sec(it) }, { p().glide }) { v -> up { it.copy(glide = v) } }, LayoutParams(0, dp(92), 1f))
        r2.addView(knob(ctx.getString(R.string.k_volume), 0.0, 1.0, false, { pct(it) }, { p().volume.toDouble() }) { v -> up { it.copy(volume = v.toFloat()) } }, LayoutParams(0, dp(92), 1f))
        addView(r2, lp())

        // modalità e ottava
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        monoSeg = Segmented(ctx, listOf(ctx.getString(R.string.voice_mono), ctx.getString(R.string.voice_poly)), 0) { i ->
            Engine.panic()
            Engine.update(false) { it.copy(mono = i == 0) }
        }
        row.addView(monoSeg, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(small("−") { shift(-12) }, LayoutParams(dp(44), dp(44)).also { it.marginStart = dp(12) })
        tvOct = Ui.label(ctx, "", 15f, Ui.text(ctx), true)
        tvOct.gravity = Gravity.CENTER
        row.addView(tvOct, LayoutParams(dp(78), ViewGroup.LayoutParams.WRAP_CONTENT))
        row.addView(small("+") { shift(12) }, LayoutParams(dp(44), dp(44)))
        addView(row, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.topMargin = dp(4); it.bottomMargin = dp(10) })

        // tastiera
        val kc = W.card(ctx)
        kc.addView(keyboard, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(kc, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).also { it.height = 0 })
        kc.minimumHeight = dp(150)
        keyboard.onOn = { n, v -> Engine.noteOn(n, v) }
        keyboard.onOff = { n -> Engine.noteOff(n) }
    }

    private fun small(t: String, onClick: () -> Unit): TextView {
        val v = Ui.label(ctx, t, 22f, Ui.text(ctx), true)
        v.gravity = Gravity.CENTER
        v.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 14)
        v.setOnClickListener { Ui.tap(it); onClick() }
        return v
    }

    private fun shift(d: Int) {
        val nb = (Prefs.kbBase + d).coerceIn(12, 60)
        if (nb == Prefs.kbBase) return
        Prefs.kbBase = nb
        keyboard.base = nb
        refreshOctave()
    }

    private fun refreshOctave() {
        val b = Prefs.kbBase
        tvOct.text = Scales.noteName(b) + "–" + Scales.noteName(b + 24)
    }

    fun refresh() {
        for (k in knobs) k.sync()
        monoSeg.select(if (Engine.patch.mono) 0 else 1)
        tvPreset.text = "🎛  " + (if (Prefs.presetName.isEmpty()) ctx.getString(R.string.preset_custom) else Prefs.presetName) + "   ▾"
        keyboard.base = Prefs.kbBase
        refreshOctave()
    }

    fun onHidden() = keyboard.releaseAll()

    /** ~30 volte al secondo mentre la pagina è visibile */
    fun frame() {
        analyzer.analyze(Engine.outRing, -80.0)
        Engine.outRing.latest(scope.data, 4096)
        specView.invalidate()
        scope.invalidate()
        keyboard.invalidate()
    }
}
