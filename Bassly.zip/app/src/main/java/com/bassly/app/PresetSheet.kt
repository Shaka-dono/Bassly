package com.bassly.app

import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** Foglio dei preset: suoni di fabbrica e suoni salvati dall'utente. */
class PresetSheet(private val act: MainActivity, private val onLoaded: () -> Unit) {

    private val ctx = act
    private val dialog = BottomSheetDialog(ctx)
    private val root = LinearLayout(ctx)

    private fun dp(v: Int) = Ui.dp(ctx, v)

    private fun item(name: String, selected: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(ctx)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(20), dp(14), dp(20), dp(14))
        r.addView(Ui.label(ctx, name, 17f, if (selected) Ui.primary(ctx) else Ui.text(ctx), selected),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (selected) r.addView(Ui.label(ctx, "✓", 17f, Ui.primary(ctx), true))
        val tv = android.util.TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        r.setBackgroundResource(tv.resourceId)
        r.setOnClickListener { Ui.tap(it); onClick() }
        if (onLong != null) r.setOnLongClickListener { onLong(); true }
        return r
    }

    private fun load(name: String, p: BassPatch) {
        Engine.panic()
        Prefs.presetName = name
        Engine.update(true) { p }
        dialog.dismiss()
        onLoaded()
    }

    private fun build() {
        root.removeAllViews()
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(24))

        val save = Ui.label(ctx, ctx.getString(R.string.pre_save), 16f, Ui.onPrimary(ctx), true)
        save.gravity = Gravity.CENTER
        save.setPadding(dp(16), dp(15), dp(16), dp(15))
        save.background = Ui.roundBg(ctx, Ui.primary(ctx), 18)
        save.setOnClickListener { Ui.tap(it); saveDialog() }
        root.addView(save, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(W.title(ctx, ctx.getString(R.string.pre_mine)))
        val mine = Prefs.presets(ctx)
        val c1 = W.card(ctx)
        if (mine.isEmpty()) {
            c1.addView(Ui.label(ctx, ctx.getString(R.string.pre_empty), 14.5f, Ui.secondary(ctx)).also { it.setPadding(dp(20), dp(16), dp(20), dp(16)) })
        } else {
            for ((i, m) in mine.withIndex()) {
                if (i > 0) c1.addView(W.divider(ctx))
                c1.addView(item(m.name, Prefs.presetName == m.name, { load(m.name, m.patch) }) { confirmDelete(i, m.name) })
            }
            c1.addView(Ui.label(ctx, ctx.getString(R.string.pre_hold_hint), 12.5f, Ui.secondary(ctx)).also { it.setPadding(dp(20), dp(2), dp(20), dp(12)) })
        }
        root.addView(c1)

        root.addView(W.title(ctx, ctx.getString(R.string.pre_builtin)))
        val c2 = W.card(ctx)
        for ((i, e) in Factory.list.withIndex()) {
            if (i > 0) c2.addView(W.divider(ctx))
            c2.addView(item(e.name, Prefs.presetName == e.name, { load(e.name, e.patch) }, null))
        }
        root.addView(c2)
    }

    fun show() {
        build()
        val sv = ScrollView(ctx)
        sv.addView(root)
        dialog.setContentView(sv)
        dialog.behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
        dialog.behavior.skipCollapsed = true
        dialog.show()
    }

    private fun confirmDelete(i: Int, name: String) {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(ctx.getString(R.string.pre_delete_title, name))
            .setPositiveButton(R.string.btn_delete) { _, _ ->
                val l = Prefs.presets(ctx)
                if (i < l.size) l.removeAt(i)
                Prefs.savePresets(ctx, l)
                build()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }

    private fun saveDialog() {
        val et = EditText(ctx)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.hint = ctx.getString(R.string.pre_name_hint)
        et.setSingleLine()
        val wrap = LinearLayout(ctx)
        wrap.setPadding(dp(24), dp(8), dp(24), 0)
        wrap.addView(et, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.pre_name_title)
            .setView(wrap)
            .setPositiveButton(R.string.btn_save) { _, _ ->
                val name = et.text.toString().trim().ifEmpty { ctx.getString(R.string.pre_default_name) }
                val l = Prefs.presets(ctx)
                l.removeAll { it.name == name }
                l.add(SavedPreset(name, Engine.patch))
                Prefs.savePresets(ctx, l)
                Prefs.presetName = name
                build()
                onLoaded()
                Toast.makeText(ctx, R.string.pre_saved, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.btn_cancel, null)
            .show()
    }
}
