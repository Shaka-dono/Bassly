package com.bassly.app

import kotlin.random.Random

/** Scale e tonalità condivise da pad e sequencer. */
object Scales {
    val names = listOf("Minor", "Major", "Minor pent.", "Major pent.", "Dorian", "Phrygian", "Harm. minor", "Blues", "Chromatic")
    val intervals = listOf(
        intArrayOf(0, 2, 3, 5, 7, 8, 10),
        intArrayOf(0, 2, 4, 5, 7, 9, 11),
        intArrayOf(0, 3, 5, 7, 10),
        intArrayOf(0, 2, 4, 7, 9),
        intArrayOf(0, 2, 3, 5, 7, 9, 10),
        intArrayOf(0, 1, 3, 5, 7, 8, 10),
        intArrayOf(0, 2, 3, 5, 7, 8, 11),
        intArrayOf(0, 3, 5, 6, 7, 10),
        IntArray(12) { it }
    )
    val keys = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

    /** nota MIDI del grado `degree` della scala, con la tonica più bassa a `base` */
    fun noteAt(scale: Int, root: Int, base: Int, degree: Int): Int {
        val iv = intervals[scale.coerceIn(0, intervals.size - 1)]
        val oct = Math.floorDiv(degree, iv.size)
        val d = Math.floorMod(degree, iv.size)
        return base + root + 12 * oct + iv[d]
    }

    fun inScale(scale: Int, root: Int, note: Int): Boolean {
        val iv = intervals[scale.coerceIn(0, intervals.size - 1)]
        val pc = Math.floorMod(note - root, 12)
        for (x in iv) if (x == pc) return true
        return false
    }

    fun noteName(n: Int): String = keys[Math.floorMod(n, 12)] + (Math.floorDiv(n, 12) - 1)

    fun isBlack(n: Int): Boolean = when (Math.floorMod(n, 12)) {
        1, 3, 6, 8, 10 -> true
        else -> false
    }

    /**
     * Riempie il pattern con una linea di basso casuale ma musicale, nella scala scelta.
     * Le note stanno nell'ottava che parte dalla tonica; restituisce la tonica usata.
     */
    fun randomize(seq: Sequencer, scale: Int, root: Int, lo: Int, rnd: Random = Random.Default): Int {
        val iv = intervals[scale.coerceIn(0, intervals.size - 1)]
        val rootNote = lo + Math.floorMod(root - lo, 12)
        val pool = ArrayList<Int>()
        for (o in 0..1) for (x in iv) {
            val n = rootNote + 12 * o + x
            if (n <= rootNote + 12) pool.add(n)
        }
        for (i in 0 until Sequencer.MAX) {
            val s = seq.steps[i]
            val strong = i % 4 == 0
            s.on = if (strong) rnd.nextFloat() < 0.9f else rnd.nextFloat() < 0.55f
            // più probabili le note gravi
            val pick = minOf(rnd.nextInt(pool.size), rnd.nextInt(pool.size))
            s.note = if (i == 0 || rnd.nextFloat() < 0.3f) rootNote else pool[pick]
            s.accent = s.on && rnd.nextFloat() < 0.22f
            s.slide = s.on && i > 0 && seq.steps[i - 1].on && rnd.nextFloat() < 0.18f
        }
        return rootNote
    }
}

/** Preset di fabbrica. I nomi sono termini musicali, uguali in italiano e in inglese. */
object Factory {
    class Entry(val name: String, val patch: BassPatch)

    val list: List<Entry> = listOf(
        Entry("Sub Pure", BassPatch(osc1 = 0, osc2 = 0, osc2Level = 0f, sub = 0.8f, cutoff = 900.0, res = 0.05f, drive = 0f, envAmt = 0f,
            attack = 0.004, decay = 0.3, sustain = 1f, release = 0.12, glide = 0.03)),
        Entry("808 Boom", BassPatch(osc1 = 0, osc2 = 0, osc2Level = 0f, sub = 0.9f, cutoff = 700.0, res = 0.05f, drive = 0.25f, envAmt = 0f,
            punch = 0.7f, attack = 0.002, decay = 1.1, sustain = 0.0f, release = 0.5, glide = 0.0, mono = true)),
        Entry("Reese", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 0.9f, detune = 22.0, sub = 0.5f, cutoff = 420.0, res = 0.2f, drive = 0.35f,
            envAmt = 0.1f, attack = 0.01, decay = 0.4, sustain = 1f, release = 0.3, lfoTarget = 0, lfoShape = 0, lfoRate = 0.35, lfoDepth = 0.18f)),
        Entry("Acid 303", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 0f, sub = 0f, cutoff = 260.0, res = 0.78f, drive = 0.35f, envAmt = 0.75f,
            fDecay = 0.22, attack = 0.002, decay = 0.25, sustain = 0.7f, release = 0.08, glide = 0.07, mono = true)),
        Entry("Wobble", BassPatch(osc1 = 3, osc2 = 1, osc2Level = 0.6f, detune = 7.0, sub = 0.6f, cutoff = 380.0, res = 0.45f, drive = 0.45f,
            envAmt = 0f, attack = 0.005, decay = 0.4, sustain = 1f, release = 0.2, lfoTarget = 0, lfoShape = 0, lfoSync = true, lfoDiv = 3, lfoDepth = 0.65f)),
        Entry("Wobble Slow", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 0.7f, detune = 12.0, sub = 0.6f, cutoff = 300.0, res = 0.5f, drive = 0.4f,
            envAmt = 0f, sustain = 1f, release = 0.25, lfoShape = 1, lfoSync = true, lfoDiv = 2, lfoDepth = 0.8f)),
        Entry("Growl", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 0.8f, detune = 30.0, sub = 0.35f, cutoff = 520.0, res = 0.6f, drive = 0.75f,
            envAmt = 0.2f, sustain = 1f, release = 0.15, lfoTarget = 0, lfoShape = 3, lfoRate = 7.0, lfoDepth = 0.45f)),
        Entry("Pluck", BassPatch(osc1 = 3, osc2 = 1, osc2Level = 0.3f, detune = 5.0, sub = 0.5f, cutoff = 180.0, res = 0.35f, drive = 0.15f,
            envAmt = 0.8f, fDecay = 0.13, attack = 0.002, decay = 0.22, sustain = 0.0f, release = 0.1)),
        Entry("Funk", BassPatch(osc1 = 1, osc2 = 3, osc2Level = 0.35f, detune = 4.0, sub = 0.4f, cutoff = 240.0, res = 0.5f, drive = 0.2f,
            envAmt = 0.7f, fDecay = 0.18, attack = 0.002, decay = 0.3, sustain = 0.45f, release = 0.12, glide = 0.02)),
        Entry("Hoover", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 1f, detune = 38.0, sub = 0.3f, cutoff = 1400.0, res = 0.3f, drive = 0.85f,
            envAmt = 0.2f, attack = 0.02, sustain = 1f, release = 0.35, glide = 0.12, punch = 0.15f)),
        Entry("Moog Round", BassPatch(osc1 = 2, osc2 = 1, osc2Level = 0.5f, detune = 3.0, sub = 0.5f, cutoff = 330.0, res = 0.4f, drive = 0.2f,
            envAmt = 0.45f, fDecay = 0.35, attack = 0.003, decay = 0.4, sustain = 0.65f, release = 0.15, glide = 0.05)),
        Entry("Dark Saw", BassPatch(osc1 = 3, osc2 = 3, osc2Level = 0.5f, detune = 10.0, sub = 0.55f, cutoff = 230.0, res = 0.15f, drive = 0.3f,
            envAmt = 0.25f, sustain = 0.9f, release = 0.2)),
        Entry("Square Punch", BassPatch(osc1 = 1, osc2 = 1, osc2Level = 0.5f, osc2Semi = 0, detune = 6.0, sub = 0.6f, subWave = 0, cutoff = 420.0, res = 0.25f,
            drive = 0.25f, envAmt = 0.5f, fDecay = 0.2, decay = 0.25, sustain = 0.8f, release = 0.1, punch = 0.2f)),
        Entry("Poly Pad Low", BassPatch(osc1 = 3, osc2 = 2, osc2Level = 0.6f, detune = 14.0, sub = 0.2f, cutoff = 700.0, res = 0.15f, drive = 0.05f,
            envAmt = 0.2f, attack = 0.25, decay = 0.6, sustain = 0.8f, release = 0.8, mono = false, glide = 0.0))
    )
}

/** Interpreta i byte MIDI in arrivo (anche con "running status" e messaggi spezzati). */
class MidiParser(private val sink: Sink) {
    interface Sink {
        fun noteOn(ch: Int, note: Int, vel: Int)
        fun noteOff(ch: Int, note: Int)
        fun cc(ch: Int, num: Int, value: Int)
        fun bend(ch: Int, value: Int)      // 0..16383, centro 8192
        fun program(ch: Int, num: Int)
    }

    private var status = 0
    private val data = IntArray(2)
    private var n = 0

    fun feed(buf: ByteArray, offset: Int, count: Int) {
        for (i in offset until offset + count) byte(buf[i].toInt() and 0xFF)
    }

    private fun need(st: Int): Int = when (st and 0xF0) {
        0xC0, 0xD0 -> 1
        0x80, 0x90, 0xA0, 0xB0, 0xE0 -> 2
        else -> 0
    }

    private fun byte(b: Int) {
        if (b >= 0xF8) return                // clock e real-time: ignorati
        if (b >= 0x80) {
            status = if (b >= 0xF0) 0 else b  // messaggi di sistema azzerano lo stato
            n = 0
            return
        }
        if (status == 0) return
        data[n++] = b
        if (n >= need(status)) {
            val ch = status and 0x0F
            when (status and 0xF0) {
                0x90 -> if (data[1] == 0) sink.noteOff(ch, data[0]) else sink.noteOn(ch, data[0], data[1])
                0x80 -> sink.noteOff(ch, data[0])
                0xB0 -> sink.cc(ch, data[0], data[1])
                0xE0 -> sink.bend(ch, data[0] or (data[1] shl 7))
                0xC0 -> sink.program(ch, data[0])
            }
            n = 0
        }
    }
}
