package com.bassly.app

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.PreferenceManager
import org.json.JSONArray
import org.json.JSONObject

class SavedPreset(val name: String, val patch: BassPatch)

object Prefs {
    fun sp(c: Context): SharedPreferences = PreferenceManager.getDefaultSharedPreferences(c)

    fun accent(c: Context): String = sp(c).getString("accent", "orange") ?: "orange"
    fun a4(c: Context): Double = (sp(c).getString("a4", "440") ?: "440").toDoubleOrNull() ?: 440.0
    fun floorDb(c: Context): Double = (sp(c).getString("floor_db", "-80") ?: "-80").toDoubleOrNull() ?: -80.0
    fun keepScreen(c: Context): Boolean = sp(c).getBoolean("keep_screen", true)
    fun lastTab(c: Context): Int = sp(c).getInt("tab", 0)

    var root = 9
    var scale = 0
    var kbBase = 36
    var padBase = 24
    var padLatch = false
    var seqLow = 28
    var presetName = ""

    fun loadMisc(c: Context) {
        val s = sp(c)
        root = s.getInt("root", 9)
        scale = s.getInt("scale", 0)
        kbBase = s.getInt("kb_base", 36)
        padBase = s.getInt("pad_base", 24)
        padLatch = s.getBoolean("pad_latch", false)
        seqLow = s.getInt("seq_low", 28)
        presetName = s.getString("preset_name", "") ?: ""
    }

    fun saveMisc(c: Context) {
        sp(c).edit().putInt("root", root).putInt("scale", scale).putInt("kb_base", kbBase)
            .putInt("pad_base", padBase).putBoolean("pad_latch", padLatch).putInt("seq_low", seqLow)
            .putString("preset_name", presetName).apply()
    }

    // ---- patch <-> JSON ----
    fun toJson(p: BassPatch): JSONObject = JSONObject().apply {
        put("osc1", p.osc1); put("osc2", p.osc2); put("osc2Level", p.osc2Level.toDouble())
        put("osc2Semi", p.osc2Semi); put("detune", p.detune); put("sub", p.sub.toDouble())
        put("subWave", p.subWave); put("noise", p.noise.toDouble()); put("cutoff", p.cutoff)
        put("res", p.res.toDouble()); put("drive", p.drive.toDouble()); put("envAmt", p.envAmt.toDouble())
        put("fDecay", p.fDecay); put("punch", p.punch.toDouble()); put("attack", p.attack)
        put("decay", p.decay); put("sustain", p.sustain.toDouble()); put("release", p.release)
        put("lfoTarget", p.lfoTarget); put("lfoShape", p.lfoShape); put("lfoRate", p.lfoRate)
        put("lfoSync", p.lfoSync); put("lfoDiv", p.lfoDiv); put("lfoDepth", p.lfoDepth.toDouble())
        put("mono", p.mono); put("glide", p.glide); put("volume", p.volume.toDouble())
    }

    fun fromJson(o: JSONObject): BassPatch {
        val d = BassPatch()
        return BassPatch(
            osc1 = o.optInt("osc1", d.osc1), osc2 = o.optInt("osc2", d.osc2),
            osc2Level = o.optDouble("osc2Level", d.osc2Level.toDouble()).toFloat(),
            osc2Semi = o.optInt("osc2Semi", d.osc2Semi), detune = o.optDouble("detune", d.detune),
            sub = o.optDouble("sub", d.sub.toDouble()).toFloat(), subWave = o.optInt("subWave", d.subWave),
            noise = o.optDouble("noise", d.noise.toDouble()).toFloat(), cutoff = o.optDouble("cutoff", d.cutoff),
            res = o.optDouble("res", d.res.toDouble()).toFloat(), drive = o.optDouble("drive", d.drive.toDouble()).toFloat(),
            envAmt = o.optDouble("envAmt", d.envAmt.toDouble()).toFloat(), fDecay = o.optDouble("fDecay", d.fDecay),
            punch = o.optDouble("punch", d.punch.toDouble()).toFloat(), attack = o.optDouble("attack", d.attack),
            decay = o.optDouble("decay", d.decay), sustain = o.optDouble("sustain", d.sustain.toDouble()).toFloat(),
            release = o.optDouble("release", d.release), lfoTarget = o.optInt("lfoTarget", d.lfoTarget),
            lfoShape = o.optInt("lfoShape", d.lfoShape), lfoRate = o.optDouble("lfoRate", d.lfoRate),
            lfoSync = o.optBoolean("lfoSync", d.lfoSync), lfoDiv = o.optInt("lfoDiv", d.lfoDiv),
            lfoDepth = o.optDouble("lfoDepth", d.lfoDepth.toDouble()).toFloat(),
            mono = o.optBoolean("mono", d.mono), glide = o.optDouble("glide", d.glide),
            volume = o.optDouble("volume", d.volume.toDouble()).toFloat()
        )
    }

    fun savePatch(c: Context, p: BassPatch) {
        sp(c).edit().putString("patch", toJson(p).toString()).apply()
    }

    fun loadPatch(c: Context): BassPatch = try {
        fromJson(JSONObject(sp(c).getString("patch", "{}") ?: "{}"))
    } catch (e: Exception) {
        BassPatch()
    }

    // ---- sequencer ----
    fun saveSeq(c: Context, s: Sequencer) {
        val o = JSONObject()
        o.put("bpm", s.bpm); o.put("swing", s.swing.toDouble()); o.put("gate", s.gate.toDouble())
        o.put("length", s.length); o.put("transpose", s.transpose)
        val arr = JSONArray()
        for (st in s.steps) arr.put(JSONArray().put(if (st.on) 1 else 0).put(st.note).put(if (st.accent) 1 else 0).put(if (st.slide) 1 else 0))
        o.put("steps", arr)
        sp(c).edit().putString("seq", o.toString()).apply()
    }

    fun loadSeq(c: Context, s: Sequencer) {
        val str = sp(c).getString("seq", null)
        if (str == null) {
            // schema di partenza: A minore, linea semplice
            val notes = intArrayOf(33, 0, 33, 36, 0, 33, 0, 31, 33, 0, 33, 36, 0, 40, 38, 0)
            for (i in 0 until Sequencer.MAX) {
                s.steps[i].on = notes[i] != 0
                s.steps[i].note = if (notes[i] != 0) notes[i] else 33
                s.steps[i].accent = i == 3 || i == 13
                s.steps[i].slide = i == 14
            }
            return
        }
        try {
            val o = JSONObject(str)
            s.bpm = o.optDouble("bpm", 110.0)
            s.swing = o.optDouble("swing", 0.0).toFloat()
            s.gate = o.optDouble("gate", 0.6).toFloat()
            s.length = o.optInt("length", 16).coerceIn(2, Sequencer.MAX)
            s.transpose = o.optInt("transpose", 0).coerceIn(-12, 12)
            val arr = o.getJSONArray("steps")
            for (i in 0 until minOf(arr.length(), Sequencer.MAX)) {
                val a = arr.getJSONArray(i)
                s.steps[i].on = a.optInt(0) == 1
                s.steps[i].note = a.optInt(1, 33)
                s.steps[i].accent = a.optInt(2) == 1
                s.steps[i].slide = a.optInt(3) == 1
            }
        } catch (e: Exception) {
        }
    }

    // ---- preset dell'utente ----
    fun presets(c: Context): MutableList<SavedPreset> {
        val out = mutableListOf<SavedPreset>()
        try {
            val arr = JSONArray(sp(c).getString("presets", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(SavedPreset(o.getString("name"), fromJson(o.getJSONObject("patch"))))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun savePresets(c: Context, list: List<SavedPreset>) {
        val arr = JSONArray()
        for (p in list) arr.put(JSONObject().put("name", p.name).put("patch", toJson(p.patch)))
        sp(c).edit().putString("presets", arr.toString()).apply()
    }
}
