package com.bassly.app

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

/** Pagina "Suono": tutti i parametri del sintetizzatore. */
class SoundPage(private val act: MainActivity) : ScrollView(act) {

    private val ctx = act
    private val root = LinearLayout(ctx)
    private val syncs = ArrayList<() -> Unit>()
    private lateinit var tvPreset: TextView
    private lateinit var rateRow: ParamRow
    private lateinit var divSeg: LinearLayout

    private fun dp(v: Int) = Ui.dp(ctx, v)
    private fun p() = Engine.patch
    private fun up(f: (BassPatch) -> BassPatch) { Engine.update(false, f) }
    private fun pct(v: Double) = "${(v * 100).roundToInt()}%"
    private fun str(id: Int) = ctx.getString(id)

    private fun row(
        card: LinearLayout, title: String, min: Double, max: Double, log: Boolean, show: (Double) -> String,
        get: () -> Double, set: (Double) -> Unit
    ): ParamRow {
        if (card.childCount > 0) card.addView(W.divider(ctx))
        val r = ParamRow(ctx, title, min, max, log, show, get, set)
        card.addView(r)
        syncs.add { r.sync() }
        return r
    }

    private fun seg(card: LinearLayout, title: String, items: List<String>, get: () -> Int, set: (Int) -> Unit): Segmented {
        if (card.childCount > 0) card.addView(W.divider(ctx))
        val s = Segmented(ctx, items, get()) { set(it) }
        card.addView(W.segRow(ctx, title, s))
        syncs.add { s.select(get()) }
        return s
    }

    private fun section(title: String): LinearLayout {
        root.addView(W.title(ctx, title))
        val c = W.card(ctx)
        root.addView(c)
        return c
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), 0, dp(16), dp(28))
        addView(root)

        tvPreset = Ui.label(ctx, "", 16f, Ui.text(ctx), true)
        tvPreset.setPadding(dp(16), dp(10), dp(16), dp(10))
        tvPreset.background = Ui.roundBg(ctx, Ui.surfaceVariant(ctx), 16)
        tvPreset.maxLines = 1
        tvPreset.ellipsize = android.text.TextUtils.TruncateAt.END
        tvPreset.setOnClickListener { Ui.tap(it); act.showPresets() }
        root.addView(tvPreset, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val waves = ctx.resources.getStringArray(R.array.wave_short).toList()

        val o1 = section(str(R.string.sec_osc1))
        seg(o1, "", waves, { p().osc1 }) { v -> up { it.copy(osc1 = v) } }

        val o2 = section(str(R.string.sec_osc2))
        seg(o2, "", waves, { p().osc2 }) { v -> up { it.copy(osc2 = v) } }
        row(o2, str(R.string.p_level), 0.0, 1.0, false, { pct(it) }, { p().osc2Level.toDouble() }) { v -> up { it.copy(osc2Level = v.toFloat()) } }
        row(o2, str(R.string.p_semi), -12.0, 12.0, false, { "%+d".format(it.roundToInt()) }, { p().osc2Semi.toDouble() }) { v -> up { it.copy(osc2Semi = v.roundToInt()) } }
        row(o2, str(R.string.p_detune), 0.0, 50.0, false, { "%.0f ct".format(it) }, { p().detune }) { v -> up { it.copy(detune = v) } }

        val sb = section(str(R.string.sec_sub))
        row(sb, str(R.string.p_level), 0.0, 1.0, false, { pct(it) }, { p().sub.toDouble() }) { v -> up { it.copy(sub = v.toFloat()) } }
        seg(sb, str(R.string.p_wave), listOf(waves[0], waves[1]), { p().subWave }) { v -> up { it.copy(subWave = v) } }
        row(sb, str(R.string.p_noise), 0.0, 1.0, false, { pct(it) }, { p().noise.toDouble() }) { v -> up { it.copy(noise = v.toFloat()) } }

        val fl = section(str(R.string.sec_filter))
        row(fl, str(R.string.k_cutoff), 40.0, 12000.0, true, { Fmt.hz(it) }, { p().cutoff }) { v -> up { it.copy(cutoff = v) } }
        row(fl, str(R.string.k_reso), 0.0, 1.0, false, { pct(it) }, { p().res.toDouble() }) { v -> up { it.copy(res = v.toFloat()) } }
        row(fl, str(R.string.k_drive), 0.0, 1.0, false, { pct(it) }, { p().drive.toDouble() }) { v -> up { it.copy(drive = v.toFloat()) } }
        row(fl, str(R.string.k_env), 0.0, 1.0, false, { pct(it) }, { p().envAmt.toDouble() }) { v -> up { it.copy(envAmt = v.toFloat()) } }
        row(fl, str(R.string.k_decay), 0.03, 3.0, true, { Fmt.sec(it) }, { p().fDecay }) { v -> up { it.copy(fDecay = v) } }
        row(fl, str(R.string.k_punch), 0.0, 1.0, false, { pct(it) }, { p().punch.toDouble() }) { v -> up { it.copy(punch = v.toFloat()) } }

        val am = section(str(R.string.sec_amp))
        row(am, str(R.string.p_attack), 0.002, 2.0, true, { Fmt.sec(it) }, { p().attack }) { v -> up { it.copy(attack = v) } }
        row(am, str(R.string.p_decay), 0.01, 3.0, true, { Fmt.sec(it) }, { p().decay }) { v -> up { it.copy(decay = v) } }
        row(am, str(R.string.p_sustain), 0.0, 1.0, false, { pct(it) }, { p().sustain.toDouble() }) { v -> up { it.copy(sustain = v.toFloat()) } }
        row(am, str(R.string.p_release), 0.01, 4.0, true, { Fmt.sec(it) }, { p().release }) { v -> up { it.copy(release = v) } }

        val lf = section(str(R.string.sec_lfo))
        seg(lf, str(R.string.p_target), ctx.resources.getStringArray(R.array.lfo_targets).toList(), { p().lfoTarget }) { v -> up { it.copy(lfoTarget = v) } }
        seg(lf, str(R.string.p_shape), ctx.resources.getStringArray(R.array.lfo_shapes).toList(), { p().lfoShape }) { v -> up { it.copy(lfoShape = v) } }
        seg(lf, str(R.string.p_timing), listOf(str(R.string.lfo_free), str(R.string.lfo_sync)), { if (p().lfoSync) 1 else 0 }) { v ->
            up { it.copy(lfoSync = v == 1) }
            applyLfoVisibility()
        }
        rateRow = row(lf, str(R.string.p_rate), 0.05, 20.0, true, { "%.2f Hz".format(it) }, { p().lfoRate }) { v -> up { it.copy(lfoRate = v) } }
        // divisione tempo
        lf.addView(W.divider(ctx))
        divSeg = LinearLayout(ctx)
        divSeg.orientation = LinearLayout.VERTICAL
        val ds = Segmented(ctx, Lfo.divNames, p().lfoDiv) { v -> up { it.copy(lfoDiv = v) } }
        divSeg.addView(W.segRow(ctx, str(R.string.p_division), ds))
        syncs.add { ds.select(p().lfoDiv) }
        lf.addView(divSeg)
        row(lf, str(R.string.p_depth), 0.0, 1.0, false, { pct(it) }, { p().lfoDepth.toDouble() }) { v -> up { it.copy(lfoDepth = v.toFloat()) } }

        val vc = section(str(R.string.sec_voice))
        seg(vc, "", listOf(str(R.string.voice_mono), str(R.string.voice_poly)), { if (p().mono) 0 else 1 }) { v ->
            Engine.panic()
            up { it.copy(mono = v == 0) }
        }
        row(vc, str(R.string.k_glide), 0.0, 0.6, false, { Fmt.sec(it) }, { p().glide }) { v -> up { it.copy(glide = v) } }
        row(vc, str(R.string.k_volume), 0.0, 1.0, false, { pct(it) }, { p().volume.toDouble() }) { v -> up { it.copy(volume = v.toFloat()) } }
        applyLfoVisibility()
    }

    private fun applyLfoVisibility() {
        val sync = p().lfoSync
        rateRow.visibility = if (sync) View.GONE else View.VISIBLE
        divSeg.visibility = if (sync) View.VISIBLE else View.GONE
    }

    fun refresh() {
        for (s in syncs) s()
        applyLfoVisibility()
        tvPreset.text = "🎛  " + (if (Prefs.presetName.isEmpty()) ctx.getString(R.string.preset_custom) else Prefs.presetName) + "   ▾"
    }
}
