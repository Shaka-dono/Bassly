package com.bassly.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle

/** Tiene vivo il sequencer a schermo spento e mostra i comandi nella notifica. */
class ToneService : Service() {

    companion object {
        const val ACTION_PLAY = "com.bassly.app.PLAY"
        const val ACTION_STOP = "com.bassly.app.STOP"
        const val CHANNEL = "playback"
        const val NOTIF_ID = 31

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, ToneService::class.java).setAction(ACTION_PLAY))
        }
    }

    private lateinit var session: MediaSessionCompat
    private var wake: PowerManager.WakeLock? = null
    private var foreground = false
    private val handler = Handler(Looper.getMainLooper())
    private var pendingNotify = false

    private val listener: () -> Unit = { onChanged() }

    override fun onCreate() {
        super.onCreate()
        Engine.load(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        session = MediaSessionCompat(this, "Bassly")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { if (!Engine.seqPlaying()) Engine.startSeq() }
            override fun onPause() { Engine.stopSeq() }
            override fun onStop() { Engine.stopSeq() }
        })
        session.isActive = true
        Engine.addListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Engine.stopSeq()
            shutdown()
        } else {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            foreground = true
            if (wake?.isHeld != true) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Bassly:seq").also { it.acquire(6 * 60 * 60 * 1000L) }
            }
            if (!Engine.seqPlaying()) Engine.startSeq()
        }
        return START_NOT_STICKY
    }

    private fun onChanged() {
        if (!Engine.seqPlaying()) {
            shutdown()
            return
        }
        if (!pendingNotify && foreground) {
            pendingNotify = true
            handler.postDelayed({
                pendingNotify = false
                if (Engine.seqPlaying() && foreground) {
                    (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, buildNotification())
                }
            }, 500)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopI = PendingIntent.getService(
            this, 1, Intent(this, ToneService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val t = getString(R.string.notif_title, Engine.seq.bpm.toInt())
        session.setMetadata(
            MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, t)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, getString(R.string.app_name))
                .build()
        )
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_STOP)
                .setState(PlaybackStateCompat.STATE_PLAYING, 0, 1f)
                .build()
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_wave)
            .setContentTitle(t)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .addAction(R.drawable.ic_stat_wave, getString(R.string.notif_stop), stopI)
            .setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0))
            .build()
    }

    private fun shutdown() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        if (foreground) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            foreground = false
        }
        stopSelf()
    }

    override fun onDestroy() {
        Engine.removeListener(listener)
        handler.removeCallbacksAndMessages(null)
        session.isActive = false
        session.release()
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
